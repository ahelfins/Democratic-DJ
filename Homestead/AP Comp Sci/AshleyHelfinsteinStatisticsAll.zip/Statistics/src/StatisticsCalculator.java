
public class StatisticsCalculator {
	
	public static final int MAX_POSSIBLE_VALS = 10000;
	private int[] data;
	private int realLength;
	
	public StatisticsCalculator(){
		
	}
	//1) Read from the file
	public void readData(String filename){
		ArrayReader reader = new ArrayReader(filename);
		data = new int[MAX_POSSIBLE_VALS];
		realLength = reader.fillArray(data);
	}
	//2) Calculate average of an array
	public double calcAverage(){
		long sum=0;
		for(int x=0; x<realLength; x++){
			sum+=data[x];
		}
		return sum/(double)(realLength);
	}
	
	//3) Calculate mode of an array
	public int[] findMode(int max){
		int[] modes=new int[realLength];
		int[] repetitions=new int[max+1]; 
		int maxRep=0;
		for(int x=0; x<realLength; x++){
			repetitions[data[x]]=repetitions[data[x]]+1; 
			if(repetitions[data[x]]>maxRep)
				maxRep=repetitions[data[x]];
		}
		int m=0;
		for(int i=0; i<=max; i++){
			if(repetitions[i]==maxRep){
				modes[m]=i; 
				m++;
			}
		}
		int[] finModes = new int[m];
		for(int y=0; y<m; y++)
			finModes[y]=modes[y];
		return finModes;
	}
	//4) Calculate standard deviation of an array
	public double calcStdDeviation(){
		double average=calcAverage();
		long preVar=0;
		for(int x=0; x<realLength; x++){
			preVar+=(Math.pow((data[x]-average), 2));
		}
		double variance=preVar/(double)(realLength-1);
		return Math.sqrt(variance);
	}

	
	public static void main(String[] args){
		StatisticsCalculator calc = new StatisticsCalculator();
		calc.readData("numbers4.txt");
		int[] practice = {7, 4, 8, 6, 7, 6, 4, 5, 7, 6};
		int[] modes = calc.findMode(100);
		/*for(int x: data)
		{
			System.out.println(x);
		}*/
		System.out.println(calc.calcAverage());
		System.out.println(calc.calcStdDeviation());
		for(int x: modes)
			System.out.println(x);
	}
}
