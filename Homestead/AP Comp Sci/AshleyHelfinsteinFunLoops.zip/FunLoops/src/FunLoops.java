
public class FunLoops {
	
	public static int findLCM(int a, int b){
		if(a<b){
			int temp=a;
			a=b;
			b=temp;
		}
		int i=a;
		while(i%b!=0){
			i+=a;
		}
		return i;
		/*check which is bigger
		 * start the test value at the bigger one
		 * while the test value is not divisible by the smaller one
		 * 	increase the test value by the bigger one
		 * return the test value
		 * 
		 */
			
	}
	
	public static long[] findMagicSquares(int n){
		long[] answers = new long[n];
		long magicSquare=0;
		int num=1;
		long square=1;
		int sum=0;
		for (int i=0; i<n; i++){
			while(magicSquare!=square){
				square=num*num;
				for(int x=0; sum<=square; sum+=x){
					if(sum==square){
						magicSquare=square;
						//System.out.println("Setting magic square");
					}
					x++;
				}
				num++;
				sum=0;
				//System.out.println(square+"");
			}
			answers[i]=magicSquare;
			magicSquare=0;
			//System.out.println("Found a magic square");
		}
		return answers;
	}
	
	public static void main(String args[]){
		
		System.out.println("LCM: "+ findLCM(15,18));
		System.out.println("LCM: "+ findLCM(40,12));
		System.out.println("LCM: "+ findLCM(2,7));
		System.out.println("LCM: "+ findLCM(100,5));
		int n=10;
		long[] x=new long[n];
		x=findMagicSquares(n);
		for(int i=0; i<n; i++){
			System.out.println("Magic Square " + (i+1) + ": " + x[i]);
		}
			
	}

}
