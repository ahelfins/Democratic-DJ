

import java.awt.Dimension;
import java.util.ArrayList;

import javax.swing.JFrame;

import processing.core.PApplet;

public class Main {
	
	public static void main(String args[]) {
		FileIO reader = new FileIO();
		String filename="peopleXML.xml";
		ArrayList<String> fileData=reader.readData(filename);
		PersonTranslator pt = new PersonTranslator(filename);
		
		ArrayList<Person> people = pt.getPeople();
		ArrayList<Teacher> teachers = pt.getTeachers();
		ArrayList<Student> students = pt.getStudents();
		ArrayList<CollegeStudent> collegeStudents = pt.getCollegeStudents();
				
		for(Person p: people){
			System.out.println(p);
		}
		for(Teacher t: teachers){
			System.out.println(t);
		}
		for(Student s: students){
			System.out.println(s);
		}
		for(CollegeStudent cs: collegeStudents){
			System.out.println(cs);
		}
		
		DrawingSurface drawing = new DrawingSurface();
		drawing.init();
		
		Person person=new Person("Brad", 12, "M", 40, 0);
		Teacher teacher=new Teacher("Mike", 60, "M","Chemistry", 30000, 140, 140);
		Student student=new Student("Angelica", 14, "F", "34555", 4.0, 0, 190);
		CollegeStudent collegeStudent=new CollegeStudent("Marcia", 19, "F", "45678*", 3.1, 2, "Anthropology", 200, 10);
		
		drawing.addPerson(person);
		drawing.addPerson(teacher);
		drawing.addPerson(student);
		drawing.addPerson(collegeStudent);
		
		JFrame window = new JFrame();
		window.setSize(600, 480);
		window.setMinimumSize(new Dimension(100,100));
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.add(drawing);
		window.setVisible(true);
	}

}
