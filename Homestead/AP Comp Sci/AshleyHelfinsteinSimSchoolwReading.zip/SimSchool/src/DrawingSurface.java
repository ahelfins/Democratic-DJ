import java.awt.geom.Point2D;
import java.util.ArrayList;

import processing.core.PApplet;



public class DrawingSurface extends PApplet {
	
	private ArrayList<Person> people;
	
	
	private int ANIMATION_TIME = 100;
	private float x,y,time;
	
	public DrawingSurface() {
		people=new ArrayList<Person>();
	}
	
	// The statements in the setup() function 
	// execute once when the program begins
	public void setup() {
		//size(0,0,PApplet.P3D);
	}
	
	public void addPerson(Person p){
		people.add(p);
	}
	
	// The statements in draw() are executed until the 
	// program is stopped. Each statement is executed in 
	// sequence and after the last line is read, the first 
	// line is executed again.
	public void draw() { 
		background(255);   // Clear the screen with a white background
		fill(255);
		textAlign(CENTER);
		textSize(12);
		
		int i=0;
		while (i<people.size()) {
			
			people.get(i).draw(this);
			i++;
		}
		if (time > 0) {
			time-=2;
			float size = (float)Math.sin((ANIMATION_TIME-time)/ANIMATION_TIME*Math.PI)*10;
			ellipse(x, y, size, size);
		}

	}
	
	
}










