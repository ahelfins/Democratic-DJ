import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
/**
 * 
 * XML parsing code adapted from java-samples.com
 */
public class PersonTranslator {
	
	private Document dom;
	private ArrayList<Person> myPeople;
	private ArrayList<Teacher> myTeachers;
	private ArrayList<Student> myStudents;
	private ArrayList<CollegeStudent> myCollegeStudents;
	
	public PersonTranslator(String filename){
		myPeople=new ArrayList<Person>();
		myTeachers=new ArrayList<Teacher>();
		myStudents=new ArrayList<Student>();
		myCollegeStudents=new ArrayList<CollegeStudent>();
		parseXmlFile(filename);
		parseDocument();
		
	}
	
	public ArrayList<Person> getPeople(){
		return myPeople;
	}
	public ArrayList<Teacher> getTeachers(){
		return myTeachers;
	}
	public ArrayList<Student> getStudents(){
		return myStudents;
	}
	public ArrayList<CollegeStudent> getCollegeStudents(){
		return myCollegeStudents;
	}
	
	private void parseXmlFile(String filename){
		//get the factory
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

		try {

			//Using factory get an instance of document builder
			DocumentBuilder db = dbf.newDocumentBuilder();

			//parse using builder to get DOM representation of the XML file
			dom = db.parse(filename);

		}catch(ParserConfigurationException pce) {
			pce.printStackTrace();
		}catch(SAXException se) {
			se.printStackTrace();
		}catch(IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	private void parseDocument(){
		//get the root element
		Element docEle = dom.getDocumentElement();

		//get a nodelist of elements
		NodeList nl = docEle.getElementsByTagName("Person");
		if(nl != null && nl.getLength() > 0) {
			for(int i = 0 ; i < nl.getLength();i++) {

				//get the person element
				Element pe = (Element)nl.item(i);

				//get the Person object
				Person p = getPerson(pe);

				//add it to list
				myPeople.add(p);
			}
		}
		//get a nodelist of elements
		NodeList n2 = docEle.getElementsByTagName("Teacher");
		if(n2 != null && n2.getLength() > 0) {
			for(int i = 0 ; i < n2.getLength();i++) {

				//get the person element
				Element te = (Element)n2.item(i);

				//get the Person object
				Teacher t = getTeacher(te);

				//add it to list
				myTeachers.add(t);
			}
		}
		//get a nodelist of elements
		NodeList n3 = docEle.getElementsByTagName("Student");
		if(n3 != null && n3.getLength() > 0) {
			for(int i = 0 ; i < n3.getLength();i++) {

				//get the person element
				Element st = (Element)n3.item(i);

				//get the Person object
				Student s = getStudent(st);

				//add it to list
				myStudents.add(s);
			}
		}
		//get a nodelist of elements
		NodeList n4 = docEle.getElementsByTagName("CollegeStudent");
		if(n4 != null && n4.getLength() > 0) {
			for(int i = 0 ; i < n4.getLength();i++) {

				//get the person element
				Element cs = (Element)n4.item(i);

				//get the Person object
				CollegeStudent c = getCollegeStudent(cs);

				//add it to list
				myCollegeStudents.add(c);
			}
		}
	}
	
	private Person getPerson(Element persPe) {

		//for each <Person> element get text or int values of
		//name, age and name
		String name = getTextValue(persPe,"name");
		int age = getIntValue(persPe,"age");
		String gender = getTextValue(persPe, "gender");

		//Create a new Person with the value read from the xml nodes
		Person p = new Person(name,age,gender);

		return p;
	}
	private Teacher getTeacher(Element teacTe) {

		//for each <Teacher> element get text, int or double values of
		//name, age, name, subject and salary
		String name = getTextValue(teacTe,"name");
		int age = getIntValue(teacTe,"age");
		String gender = getTextValue(teacTe, "gender");
		String subject = getTextValue(teacTe, "subject");
		double salary = getDoubleValue(teacTe, "salary");

		//Create a new Person with the value read from the xml nodes
		Teacher t = new Teacher(name,age,gender,subject,salary);

		return t;
	}
	private Student getStudent(Element studSt) {

		//for each <Student> element get text, int or double values of
		//name ,age, name, id and gpa
		String name = getTextValue(studSt,"name");
		int age = getIntValue(studSt,"age");
		String gender = getTextValue(studSt, "gender");
		String id = getTextValue(studSt, "ID");
		double gpa = getDoubleValue(studSt, "GPA");

		//Create a new Person with the value read from the xml nodes
		Student s = new Student(name,age,gender, id, gpa);

		return s;
	}
	private CollegeStudent getCollegeStudent(Element collSt) {

		//for each <Student> element get text, int or double values of
		//name ,age, name, id and gpa
		String name = getTextValue(collSt,"name");
		int age = getIntValue(collSt,"age");
		String gender = getTextValue(collSt, "gender");
		String id = getTextValue(collSt, "ID");
		double gpa = getDoubleValue(collSt, "GPA");
		int year = getIntValue(collSt, "year");
		String major = getTextValue(collSt, "major");

		//Create a new Person with the value read from the xml nodes
		CollegeStudent c = new CollegeStudent(name,age,gender, id, gpa, year, major);

		return c;
	}
	
	private String getTextValue(Element ele, String tagName) {
		String textVal = null;
		NodeList nl = ele.getElementsByTagName(tagName);
		if(nl != null && nl.getLength() > 0) {
			Element el = (Element)nl.item(0);
			textVal = el.getFirstChild().getNodeValue();
		}

		return textVal;
	}
	private int getIntValue(Element ele, String tagName) {
		//in production application you would catch the exception
		return Integer.parseInt(getTextValue(ele,tagName));
	}
	private double getDoubleValue(Element ele, String tagName){
		return Double.parseDouble(getTextValue(ele, tagName));
	}
	
}
