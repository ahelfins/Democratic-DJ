package info.gridworld.actor;

import java.awt.Color;

import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

public class Jumper extends Actor {
	/**
     * Constructs a bug.
     */
    public Jumper()
    {
       
    }

    /**
     * Constructs a Jumper of a given color.
     * @param jumperColor the color for this Jumper
     */
    public Jumper(Color jumperColor)
    {
        setColor(jumperColor);
    }

    
    public void act()
    {
    }

   
    public void turn()
    {
        
    }

    public void move()
    {
   
    }

    public boolean canMove()
    {
       return true;
    }
}
