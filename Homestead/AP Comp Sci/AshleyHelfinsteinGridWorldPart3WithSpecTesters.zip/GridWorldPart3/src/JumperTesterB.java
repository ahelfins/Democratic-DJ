
import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Jumper;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Location;

public class JumperTesterB {
	
    public static void main(String[] args)
    {
        ActorWorld world = new ActorWorld();
        Jumper jump = new Jumper();
        world.add(jump);
        world.add(new Rock());
        jump.moveTo(new Location(3, 1));
        jump.setDirection(Location.WEST);
        world.show();
        
    }
	

}
