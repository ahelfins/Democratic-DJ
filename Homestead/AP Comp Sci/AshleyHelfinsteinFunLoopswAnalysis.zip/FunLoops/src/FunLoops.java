

/**
 * 
 * Number of Magic Squares (n): 1		2		3		4		5		6		7		8		9		10
 * Runtime (ns):				1866, 	1555, 	1555, 	3421, 	14306, 	78372, 	449707, 492003, 2937400,17504351
 * 
 * Fibonacci Data:
 * 
 * Fibonacci Number (n):	10			20			30			40			45
 * Recursive Runtime (ns): 	8086, 		269639, 	12308194, 	1459450852, 16615153733
 * Loop Runtime (ns): 		2799, 		933, 		1244, 		1555, 		3421
 *
 * Fibonacci Number (n):			1		2		3		4		5		6		7		8		9		10
 * Recursive Number of Iterations: 	1, 		3, 		5, 		9, 		15, 	25, 	41, 	67,		109, 	177
 * Loop Number of Iterations:  		1, 		2, 		3, 		4, 		5, 		6, 		7, 		8, 		9, 		10 
 * 
 * 1. In the timing data I see that the times get increasingly larger except for the first one on the loop method. 
 * For nearly all of the times in the recursive method each time is 2 digits longer than the last, so the times clearly increase by a much larger amount in the recursive method over the loop. 
 * There is so much variation in timing data because the computers have different hardware for processing, so the time will be different due to that. 
 * In addition if there are background programs running those could affect the timing data.
 * 
 * 2. In the number of iterations for the recursive method they are all odd numbers. The loop method the number of iterations increases by 1 each time, so it is the same as n. 
 * In the recursive method, the difference between the number of iterations for each n increases. 
 * 
 * 3. The looping method is faster. This is because the looping method goes through less iterations for most of the numbers input (except 1), so it takes less time.
 *  
 * 
 * @author AHelfinstein692
 *
 */
public class FunLoops {
	private static int numberOfIterations=0;
	
	public static long factorial(long n){
		if(n==0){ //BASE CASE
			return 1;
		}
		else{ //RECURSIVE CASE
			long prevFact = factorial(n-1); 
			return n*prevFact;
		}
	}
	
	/**Returns the fibonacci number in a given position of the sequence
	 * @pre n>=0
	 * @param n the number of the position in the fibonacci sequence to be returned
	 * @return long the fibonacci number in the given position
	 */
	public static long fibonacci(long n){
		numberOfIterations++;
		if(n==0||n==1){
			return n;
		}
		else{
			long prevN=fibonacci(n-1);
			long beforePrevN=fibonacci(n-2);
			return prevN+beforePrevN;
		}
		
	}
	public static long fibonacciLoop(long n){
		long prevN=0;
		long beforePrevN=0;
		long fib=1;
		for(int i=0; i<n; i++){
			numberOfIterations++;
			beforePrevN=prevN;
			prevN=fib;
			fib=prevN+beforePrevN;
		}
		return prevN;
		
	}
	
	
	
	
	public static int findLCM(int a, int b){
		if(a<b){
			int temp=a;
			a=b;
			b=temp;
		}
		int i=a;
		while(i%b!=0){
			i+=a;
		}
		return i;
		/*check which is bigger
		 * start the test value at the bigger one
		 * while the test value is not divisible by the smaller one
		 * 	increase the test value by the bigger one
		 * return the test value
		 * 
		 */
			
	}
	
	public static long[] findMagicSquares(int n){
		long[] answers = new long[n];
		long magicSquare=0;
		long num=1;
		long square=1;
		long sum=0;
		long x=0;
		for (int i=0; i<n; i++){
			while(magicSquare!=square){
				square=num*num;
				for(; sum<=square; sum+=x){
					if(sum==square){
						magicSquare=square;
						//System.out.println("Setting magic square");
					}
					x++;
				}
				num++;
			}
			answers[i]=magicSquare;
			//System.out.println("Found a magic square");
			magicSquare=0;
		}
		return answers;
	}
	
	public static void main(String args[]){
		
		long x=0;
		for(int b=0; b<=10; b++){
			numberOfIterations=0;
			//long startTime = System.nanoTime();
			x=fibonacciLoop(b);
			System.out.println("Fibonacci " +b +": " +x);
			//long endTime = System.nanoTime();
			//System.out.print(endTime-startTime + ", ");
			//System.out.print(numberOfIterations + ", ");
		}	
		//.out.println("Factorial: "+factorial(7));
		
		
		/*System.out.println("LCM: "+ findLCM(15,18));
		System.out.println("LCM: "+ findLCM(40,12));
		System.out.println("LCM: "+ findLCM(2,7));
		System.out.println("LCM: "+ findLCM(100,5));
		int n=10;
		long[] x=new long[n];
		
		for(int b=1; b<=10; b++){
			long startTime = System.nanoTime();
			x=findMagicSquares(b);
			long endTime = System.nanoTime();
			System.out.print(endTime-startTime + ", ");
		}	
		System.out.println();
		for(int i=0; i<n; i++){
			System.out.println("Magic Square " + (i+1) + ": " + x[i]);
		}*/
			
	}

}
