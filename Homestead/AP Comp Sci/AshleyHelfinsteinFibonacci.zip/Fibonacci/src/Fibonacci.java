/**
 * @(#)Fibonacci.java
 *
 *
 */

import java.util.InputMismatchException;
import java.util.Scanner;

public class Fibonacci {

	//20th Fibonacci number is 6765
    public static int computeFibonacci(int x) {
    	if (x<0){
    		throw new IllegalArgumentException("Negative numbers are invalid here");
    	}
    	if (x <= 1) {
    		return x;
    	} else {
    		int answer = computeFibonacci(x-2) + computeFibonacci(x-1);
    		return answer;
    	}

    }

	public static void main (String[] args) {
		Scanner kboard = new Scanner (System.in);
		System.out.print("Which fibonacci number would you like to find? --> ");
		try{
			int x = kboard.nextInt();
			int answer = computeFibonacci(x);
			System.out.println ("The " + x + " fibonacci number is " + answer + ".");
		}
		catch(StackOverflowError er){
			System.out.println("You have stack overflow.");
			System.out.println("Please try again.");
		}
		catch(IllegalArgumentException ex){
			System.out.println("You entered a number out of bounds.");
			System.out.println("Please try again, entering a positive number.");
		}
		catch(InputMismatchException ex){
			System.out.println("You entered the wrong kind of data.");
			System.out.println("Please try again, entering a number.");
		}
		catch(Exception ex){
			System.out.println("You entered bad data.");
			System.out.println("Please try again.");
		}
		System.out.println("Goodbye");
	}

}



