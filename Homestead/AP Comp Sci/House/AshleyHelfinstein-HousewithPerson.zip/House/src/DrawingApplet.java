import java.awt.Dimension;

import javax.swing.JFrame;

import processing.core.PApplet;

public class DrawingApplet extends PApplet {
	
	private House house;
	private Person person;
	
	public DrawingApplet(){
		house = new House();
		person = new Person();
	}

	public void setup() {
	  size(500, 500);  // Size must be the first statement
	}
	
	// The statements in draw() are executed until the 
	// program is stopped. Each statement is executed in 
	// sequence and after the last line is read, the first 
	// line is executed again.
	public void draw() { 
		background(255); 
		// Clear the screen with a white background
		house.draw(this);
		person.draw(this);
		
		
	  
	 
	} 
	
	public void mousePressed() {
	  //move house to mouseX,mouseY location
		house.move((int)(mouseX/(width/500f)), (int)(mouseY/(height/500f)));
	}
	
	public void keyPressed() {
	  //grow or shrink house based on keyCode for up and down arrows
		if (key == CODED) {
		    if (keyCode == UP){
		    	house.changeSize(true);
		    	person.jump(false, true);
		    } else if (keyCode == DOWN) {
		    	house.changeSize(false);
		    	person.jump(false, false);
		    } 
		    else if (keyCode == RIGHT){
		    	person.jump(true, true);
		    }
		    else if (keyCode == LEFT){
		    	person.jump(true, false);
		    }
		}

	}



}
