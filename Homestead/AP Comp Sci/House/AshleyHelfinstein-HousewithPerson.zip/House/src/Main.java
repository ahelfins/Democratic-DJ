import java.awt.Dimension;

import javax.swing.JFrame;

public class Main {

	
	public static void main(String args[]) {
		DrawingApplet drawing = new DrawingApplet();
		drawing.init();
		JFrame window = new JFrame();
		window.setSize(500, 500);
		window.setMinimumSize(new Dimension(100, 100));
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.add(drawing);
		window.setVisible(true);	
	}
}
