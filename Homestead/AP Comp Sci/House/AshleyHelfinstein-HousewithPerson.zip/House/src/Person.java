import processing.core.PApplet;


public class Person {
	//fields
	private int width, height;
	private int xLeft, yTop;
	
	//constructor
	public Person(){
		//width refers to body (rect) width
		width = 40;
		height = 180;
		xLeft = 15;
		yTop = 225;
	}
	
	//methods
	//makes person move up down or side to side when arrows are pressed
	//in conjunction with house getting bigger or smaller 
	public void jump(boolean isHorizontal, boolean isPositive){
		if (isHorizontal){
			if (isPositive){
				xLeft+=width;
			}
			else{
				xLeft-=width;
			}
		}
		else if (!isHorizontal){
			if (isPositive){
				yTop-=width;
			}
			else{
				yTop+=width;
			}
		}
	}
	
	public void draw(PApplet drawer){
		drawer.stroke(0);
		//draws head
		drawer.ellipse(xLeft + width*5/8, yTop + height*5/36, width*5/4, height*5/18);
		//draws neck
		drawer.line(xLeft + width*5/8, yTop + height*5/18, xLeft + width*5/8, yTop + height*1/3);
		//draws body
		drawer.rect(xLeft + width/8, yTop + height/3, width, height*4/9, 4, 4, 4, 4);
		//draws legs
		//left leg
		drawer.line(xLeft+width/2, yTop + height*7/9, xLeft+width/4, yTop + height*17/18);
		//right leg
		drawer.line(xLeft+width*3/4, yTop + height*7/9, xLeft+width, yTop + height*17/18);
		//draws arms
		//right arm
		drawer.line(xLeft + width*9/8, yTop + height*7/18, xLeft + width*11/8, yTop + height*2/3);
		//left arm
		drawer.line(xLeft + width/8, yTop + height*7/18, xLeft-width/8, yTop + height*2/3);
		
	}
}
