import javax.swing.JFrame;

import processing.core.PApplet;

public class House extends PApplet {
	
	public static void main(String args[]) {
		House drawing = new House();
		drawing.init();
		JFrame window = new JFrame();
		window.setSize(500, 500);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.add(drawing);
		window.setVisible(true);	
	}

	public void setup() {
	  size(500, 500);  // Size must be the first statement
	  stroke(0);     // Set stroke color to black
	  frameRate(30);
	}
	// The statements in draw() are executed until the 
	// program is stopped. Each statement is executed in 
	// sequence and after the last line is read, the first 
	// line is executed again.
	public void draw() { 
		background(255);   // Clear the screen with a white background
	  //dimensions scalable, found based on original dimensions of 500x500
	  //draws house outline
	  rect(width*1/5, height*2/5, width*3/5, height*2/5);
	  //draws windows
	  rect(width*15/50, height*225/500, width*5/50, height*5/50);
	  rect(width*3/5, height*225/500, width*5/50, height*5/50);
	  //draws door
	  rect(width*225/500, height*325/500, width*5/50, height*75/500);
	  //draws roof
	  triangle(width*1/5, height*2/5, width*25/50, height*1/5, width*4/5, height*2/5);
	  
	  
	 /* 
	  * original unscalable house code: 
	  * //draws house outline
	  rect(100, 200, 300, 200);
	  //draws windows
	  rect(150, 225, 50, 50);
	  rect(300, 225, 50, 50);
	  //draws door
	  rect(225, 325, 50, 75);
	  //draws roof
	  triangle(100, 200, 250, 100, 400, 200);
	  */
	  
	} 

}
