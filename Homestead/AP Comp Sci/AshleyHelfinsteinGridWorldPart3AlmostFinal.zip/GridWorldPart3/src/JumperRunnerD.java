import info.gridworld.actor.Actor;
import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Jumper;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Location;

public class JumperRunnerD {
	public static void main(String[] args) {
		ActorWorld world = new ActorWorld();
	    world.add(new Location(6,4), new Jumper());
	    //my addition
	    world.add(new Location(4,4), new Actor());
	    //their version
	    //world.add(new Location(6,2), new Actor());
	    world.show();
	}
	
}
