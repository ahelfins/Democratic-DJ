package info.gridworld.actor;

import java.awt.Color;

import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

/**A <code>Jumper</code> is an Actor that jumps to a location two in front of it each time it moves. If there are obstacles, it does different specific actions based on the following specifications. 
 * Class specs:
  a) If the cell contains a flower, it just jumps onto the flower and turn the flower into a rock when it leaves. If it's a rock, the jumper jumps onto the rock and turns the rock into a flower when it gets off that location. 
  b) If the location two spots in front is out of bounds, then the jumper turns 90 degrees clockwise.
  c) If the jumper is facing an edge, it turns 90 degrees clockwise.
  d) If the spot two spots in front of the jumper is an actor(not a jumper, rock or a flower), the jumper jumps on the other actor and when it leaves, the other actor is turned into a Jumper facing the direction of the first jumper plus 90 degrees clockwise.
  e) If the spot two spots in front of that the jumper is another jumper, the two jumpers remove themselves from the grid, and replace themselves with rocks where they were.
 * Specs created by Group 3
 * 
 * @author Ashley Helfinstein
 * @version 4/2/16
 *
 */
public class Jumper extends Actor{
	
	private Flower flowLeft;
	private Rock roLeft;
	private Rock roLeft2;
	private Jumper jLeft;
	private boolean saveFlower;
	private boolean saveRock;
	private boolean saveJumper;
	private Location lastLoc;
	
	/**
	 * Constructs a default Jumper
	 */
	public Jumper(){
	}
	
	/**Moves Jumper in various ways based on situation:
	 * jumps two forward if possible, 
	 * turns if at the edge of Grid, 
	 * otherwise interacts with Actors in its path.
	 * @post the Jumper may be removed from Grid, as well as other Actors in its path
	 * @post different Actors may be added to Grid
	 */
	public void act(){
		Location loc = getTwoAwayLoc();
		if(loc==null){
			turn();
		}
		else if(canMove()){
			moveTo(loc);
			checkSaves();
		}
		else{
			if(getGrid().get(loc) instanceof Rock){
				getGrid().get(loc).removeSelfFromGrid();
				moveTo(loc);
				checkSaves();
				saveFlower=true;
				flowLeft=new Flower();
				lastLoc=loc;
			}
			else if(getGrid().get(loc) instanceof Flower){
				getGrid().get(loc).removeSelfFromGrid();
				moveTo(loc);
				checkSaves();
				saveRock=true;
				roLeft=new Rock();
				lastLoc=loc;
			}
			else if(getGrid().get(loc) instanceof Jumper){
				roLeft=new Rock();
				roLeft2=new Rock();
				Location secondLoc=getLocation();
				Grid<Actor> thisGrid=getGrid();
				getGrid().get(loc).removeSelfFromGrid();
				removeSelfFromGrid();
				roLeft.putSelfInGrid(thisGrid, loc);
				roLeft2.putSelfInGrid(thisGrid, secondLoc);
			}
			else if(getGrid().get(loc) instanceof Actor){
				getGrid().get(loc).removeSelfFromGrid();
				moveTo(loc);
				checkSaves();
				saveJumper=true;
				jLeft=new Jumper();
				//sets jLeft (new Jumper) to direction of this Jumper (the old Jumper) + 90 degrees clockwise
				jLeft.setDirection(getDirection()+Location.RIGHT);
				lastLoc=loc;
			}
		}
	}
	
	//checks if there are saved Actors to be placed in the Grid at the previous location of the Jumper
	//if there are, places them in the Grid
	private void checkSaves(){
		if(saveFlower){
			flowLeft.putSelfInGrid(getGrid(), lastLoc);
			saveFlower=false;
		}
		else if(saveRock){
			roLeft.putSelfInGrid(getGrid(), lastLoc);
			saveRock=false;
		}
		else if(saveJumper){
			jLeft.putSelfInGrid(getGrid(), lastLoc);
			saveJumper=false;
		}
	}
	
	/**
     * Turns the Jumper 90 degrees to the right without changing its location.
     */
    public void turn()
    {
        setDirection(getDirection() + Location.RIGHT);
    }
	
	/**Determines whether Jumper can jump forward normally (2 spaces into an empty location)
	 * 
	 * @return boolean whether the location two cells away from the current location of the Jumper (in the direction it is facing) is empty
	 */
	public boolean canMove(){
		Location loc=getTwoAwayLoc();
		if(loc!=null){
			if(getGrid().get(loc)==null)
				return true;
		}
		return false;
    }
	
	//returns null if two away loc does not exist or is out of Grid
	//otherwise returns the two away location
	private Location getTwoAwayLoc(){
		Location loc=null;
		if(getDirection()==Location.NORTH)
			loc=new Location(getLocation().getRow()-2, getLocation().getCol());
		else if(getDirection()==Location.SOUTH)
			loc=new Location(getLocation().getRow()+2, getLocation().getCol());
		else if(getDirection()==Location.EAST)
			loc=new Location(getLocation().getRow(), getLocation().getCol()+2);
		else if(getDirection()==Location.WEST)
			loc=new Location(getLocation().getRow(), getLocation().getCol()-2);
		if(loc.getCol()<0||loc.getRow()<0||(getGrid().getNumCols()!=-1&&loc.getCol()>=getGrid().getNumCols())||(getGrid().getNumRows()!=-1&&loc.getRow()>=getGrid().getNumRows()))
				loc=null;
		return loc;
	}
}
