/* 
 * AP(r) Computer Science GridWorld Case Study:
 * Copyright(c) 2005-2006 Cay S. Horstmann (http://horstmann.com)
 *
 * This code is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * @author Cay Horstmann
 */

import info.gridworld.actor.Actor;
import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Flower;
import info.gridworld.actor.Jumper;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Location;

/**
 * This class runs a world that contains a bug and a rock, added at random
 * locations. Click on empty locations to add additional actors. Click on
 * populated locations to invoke methods on their occupants. <br />
 * To build your own worlds, define your own actors and a runner class. See the
 * BoxBugRunner (in the boxBug folder) for an example. <br />
 * This class is not tested on the AP CS A and AB exams.
 */
public class BugRunner
{
    public static void main(String[] args)
    {
        ActorWorld world = new ActorWorld();
        Jumper jump = new Jumper();
        Rock ro = new Rock();
        Rock ro2 = new Rock();
        Rock ro3 = new Rock();
        Rock ro4 = new Rock();
        Flower flo = new Flower();
        Flower flo2 = new Flower();
        Flower flo3 = new Flower();
        Actor ac = new Actor();
        world.add(jump);
        world.add(ro);
        world.add(ro2);
        world.add(ro3);
        world.add(ro4);
        world.add(flo);
        world.add(flo2);
        world.add(flo3);
        world.add(ac);
        ro.moveTo(new Location(3, 6));
        ro2.moveTo(new Location(3, 4));
        flo.moveTo(new Location(3, 8));
        flo2.moveTo(new Location(4, 8));
        flo3.moveTo(new Location(6, 8));
        ac.moveTo(new Location(7, 8));
        ro3.moveTo(new Location(9, 8));
        ro4.moveTo(new Location(7, 6));
        jump.moveTo(new Location(3, 2));
        jump.setDirection(Location.EAST);
        /*for(int j=0; j<10; j++)
        	for(int i=0; i<10; i++)
        		if(!((i==0&&j==3)||(i==8&&j==3)))
        			world.add(new Location(j, i), new Flower());*/
        world.show();
    }
}
