

import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Jumper;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Location;

/**
 * This class runs a world that contains a bug and a rock, added at random
 * locations. Click on empty locations to add additional actors. Click on
 * populated locations to invoke methods on their occupants. <br />
 * To build your own worlds, define your own actors and a runner class. See the
 * BoxBugRunner (in the boxBug folder) for an example. <br />
 * This class is not tested on the AP CS A and AB exams.
 */
public class JumperERunner
{
	public static void main(String[] args)
    {
        ActorWorld world = new ActorWorld();
        
        Jumper jumper1 = new Jumper();
        Jumper jumper2 = new Jumper();
        
        world.add(jumper1);
        world.add(jumper2);
        
        jumper1.moveTo(new Location(4, 0));
        //my addition
        jumper1.setDirection(Location.EAST);
        jumper2.moveTo(new Location(6,2));
        
        world.show();
    }
}