package testers;
import shapes.*;
import javax.swing.JFrame;

import processing.core.PApplet;
/**Contains the main method for the program and functions as a tester to draw the shapes
 * 
 * @author Ashley Helfinstein
 * @version 9/27/15
 *
 */
public class Tester {
	public static void main(String args[]) {
		Circle circ = new Circle(170, 300, 200, 200);
		Rectangle rect = new Rectangle(60, 60, 100, 20);
		Sphere sph = new Sphere(140, 200, 150, 200, 200, 200);
		System.out.println("Rect Width, Height: 100, 20");
		System.out.println("Rect Location: (60, 60)");
		System.out.println("Rect Area: " + rect.findArea());
		System.out.println("Rect Perimeter: " + rect.findPerimeter());
		System.out.println("Rect (-20, 61) Is Inside: " + rect.isPointInside(-20, 61));
		System.out.println("Circle Radius: 100");
		System.out.println("Circle Location: (170, 300)");
		System.out.println("Circle Area: " + circ.findArea());
		System.out.println("Circle Circumference: " + circ.findPerimeter());
		System.out.println("Circle (180, 390) Is Inside: " + circ.isPointInside(180, 390));
		System.out.println("Sphere Radius: 100");
		System.out.println("Sphere Location: (140, 200, 150)");
		System.out.println("Sphere Volume: " + sph.findVolume());
		System.out.println("Sphere Surface Area: " + sph.findSurfaceArea());
		System.out.println("Sphere (60, 70, 10) Is Inside: " + sph.isPointInside(60, 70, 10));
		PApplet marker = new PApplet();
		marker.init();
		JFrame window = new JFrame();
		window.setSize(600, 480);
		marker.size(600, 480);
		marker.background(255);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.add(marker);
		circ.setFillColor(250, 200, 60);
		circ.changeSize(50);
		circ.draw(marker);
		/*rect.setFillColor(200, 10, 70);
		rect.changeSize(200);
		rect.draw(marker);
		sph.changeSize(-30);
		sph.setLoc(140, 200, 150);
		sph.draw(marker);*/
		window.setVisible(true);
	}
}
