import processing.core.PApplet;

public class House {
	
	//Fields
	private int width, height;
	private int xCenter, yCenter;
	
	
	//Constructor
	public House(){
		//from center of house
		xCenter = 250;
		yCenter = 250;
		//including roof
		width = 300;
		height = 300;
	}
	
	
	//Methods
	public void changeSize(boolean willIncrease){
		if (willIncrease){
			width+=50;
			height+=50;
			
		}
		else{
			width-=50;
			height-=50;
		}
	}
	public void move(int newX, int newY){
		xCenter=newX;
		yCenter=newY;
	}
	public void draw(PApplet drawer){
		
		//dimensions scalable, found based on original dimensions of 500x500
		float xRatio = drawer.width/500f;
		float yRatio = drawer.height/500f;
		drawer.scale(xRatio, yRatio);
		
		drawer.stroke(0);
		drawer.rect(xCenter-width/2, yCenter-height/6, width, height*2/3);
		//draws windows
		//left window
		drawer.rect(xCenter-width/3, yCenter-height/12, width/6, height/6);
		//right window
		drawer.rect(xCenter+width/6, yCenter-height/12, width/6, height/6);
		//draws door
		drawer.rect(xCenter-width/12, yCenter+height/4, width/6, height/4);
		//draws roof
		drawer.triangle(xCenter-width/2, yCenter-height/6, xCenter, yCenter - height/2, xCenter+width/2, yCenter-height/6);
				
				  
	}

}
