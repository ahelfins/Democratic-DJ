package shapes;

import processing.core.PApplet;

/**Represents a Regular Polygon defined by its width and height, and x and y coordinates.
 * 
 * @author Ashley Helfinstein
 * @version 9/29/15
 *
 */
public class RegularPolygon extends Shape {
	
	private int numSides;        // # of sides
	private double sideLength;   // length of side
	private Circle outCircle;    // the circumscribed Circle
	private Circle inCircle;     // the inscribed Circle
	private Line[] sides;        // array of Line objects for each side
	private double r;
	private double R;

	/**Sets up a regular polygon with the given location, number of sides and side length
	 * 
	 * @param x the x coordinate of the center of the polygon
	 * @param y the y coordinate of the center of the polygon
	 * @param numSides the number of sides the polygon has
	 * @param sideLength the length of each side of the polygon
	 */
	public RegularPolygon(int x, int y, int numSides, double sideLength ) {
		super(x, y);
		this.sideLength=sideLength;
		this.numSides=numSides;
		calcr();
		calcR();
		outCircle=new Circle(x, y, (int)R*2, (int)R*2);
		inCircle=new Circle(x, y, (int)r*2, (int)r*2);
		sides=new Line[numSides];
		int xLoc=(int)(x+R);
		int yLoc=y;
		System.out.println("Va " + calcVertexAngle());
		double angle = Math.PI-calcVertexAngle()/2;
		for(int i=0; i<numSides; i++){
			sides[i]=new Line(xLoc, yLoc, angle, sideLength);
			System.out.println("X " + xLoc+ "y " + yLoc + "angle " + angle + "l " + sideLength);
			xLoc=(int)sides[i].getPoint2X();
			yLoc=(int)sides[i].getPoint2Y();
			angle+=(numSides-1)*calcVertexAngle();
		}
	}
	
	public RegularPolygon(){
		super(200, 200);
		numSides=3;
		sideLength=100;
		calcr();
		calcR();
		outCircle=new Circle(x, y, (int)R*2, (int)R*2);
		inCircle=new Circle(x, y, (int)r*2, (int)r*2);
		sides=new Line[numSides];
		int xLoc=(int)(x+R);
		int yLoc=y;
		System.out.println("Va " + calcVertexAngle());
		double angle = Math.PI-calcVertexAngle()/2;
		for(int i=0; i<numSides; i++){
			sides[i]=new Line(xLoc, yLoc, angle, sideLength);
			System.out.println("X " + xLoc+ "y " + yLoc + "angle " + angle + "l " + sideLength);
			xLoc=(int)sides[i].getPoint2X();
			yLoc=(int)sides[i].getPoint2Y();
			angle+=(numSides-1)*calcVertexAngle();
		}
	}
	
	// private methods
   private void calcr(){
	   r=1.0/2*sideLength*(1/Math.tan(Math.PI/numSides));
   }
 
   private void calcR(){
	   R=1.0/2*sideLength*(1/Math.sin(Math.PI/numSides));
   }   
   
   // public methods
   public double calcVertexAngle(){
	   return ((double)numSides-2)/numSides*Math.PI;
	   
   }

   public double findPerimeter(){
	   return numSides*sideLength;
   }
   
   public double findArea(){
	   return 1.0/2*numSides*Math.pow(R, 2)*Math.sin(2*Math.PI/numSides);
   }

   public int getNumSides(){
	   return numSides;
   }

   public double getSideLength(){
	   return sideLength;
   }
   
   public double getR(){
	   return R;
   }
   
   public double getr(){
	   return r;
   }

   public void draw(PApplet drawer){
	   super.draw(drawer);
	   for(int i=0; i<numSides; i++){
		   sides[i].draw(drawer);
	   }
   }

   public void drawBoundingCircles(PApplet drawer){
	  super.draw(drawer);
	  inCircle.draw(drawer);
	  outCircle.draw(drawer);
   }



}
