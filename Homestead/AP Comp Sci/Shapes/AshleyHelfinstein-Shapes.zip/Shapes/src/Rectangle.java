import processing.core.PApplet;


public class Rectangle {
	//fields
	private double x, y;
	private double width, height;
	//gives rgb color for rectangle fill
	private int colorR, colorG, colorB;
	
	
	
	// Creates a default instance of a Rectangle object with all dimensions
	//  set to zero.
	public Rectangle(){
		x=0;
		y=0;
		width=0;
		height=0;
		colorR=255;
		colorG=255;
		colorB=255;
	}
	
	//Creates a new instance of a Rectangle object with the left and right
	//edges of the rectangle at x and x + width. The top and bottom edges
	//are at y and y + height.
	public Rectangle(double x, double y, double width, double height){
		this.x=x;
		this.y=y;
		this.width=width;
		this.height=height;
		colorR=255;
		colorG=255;
		colorB=255;
	}
	
	//Methods
	// Calculates and returns the perimeter of the rectangle
	public double getPerimeter(){
		return 2*width + 2*height;
	}

	// Calculates and returns the area of the rectangle
	public double getArea(){
		return width*height;
	}

	// Determines whether the point x,y is contained inside this rectangle
	public boolean isPointInside(double x, double y){
		if (x>this.x && x<(this.x+width) && y>this.y && y<(this.y+height)){
			return true;
		}
		else{
			return false;
		}
	}
	
	//changes fill color of rectangle to wantedColor
	public void changeColor(int wantedColorR, int wantedColorG, int wantedColorB){
		colorR=wantedColorR;
		colorG=wantedColorG;
		colorB=wantedColorB;
	}
	
	//makes rectangle longer horizontally
	public void lengthen(int amount){
		width +=amount;
	}

	// Draws a new instance of a Rectangle object with the left and right
	// edges of the rectangle at x and x + width. The top and bottom edges
	// are at y and y + height.
	public void draw(PApplet marker){
		marker.size(600, 480);
		marker.background(255);
		marker.stroke(0);
		//fills rectangle with desired color-white is default
		marker.fill(colorR, colorG, colorB);
		marker.rect((float)x, (float)y, (float)width, (float)height);
	}


}
