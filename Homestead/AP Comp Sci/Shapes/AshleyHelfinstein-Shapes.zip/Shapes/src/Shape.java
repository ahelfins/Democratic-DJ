import javax.swing.JFrame;

import processing.core.PApplet;

public class Shape {
	public static void main(String args[]) {
		Circle circ = new Circle(170, 300, 100);
		Rectangle rect = new Rectangle(60, 60, 100, 20);
		/*System.out.println("Rect Width, Height: 100, 20");
		System.out.println("Rect Location: (60, 60)");
		System.out.println("Rect Area: " + rect.getArea());
		System.out.println("Rect Perimeter: " + rect.getPerimeter());
		System.out.println("Rect (-20, 61) Is Inside: " + rect.isPointInside(-20, 61));
		System.out.println("Circle Radius: 100");
		System.out.println("Circle Location: (170, 300)");
		System.out.println("Circle Area: " + circ.getArea());
		System.out.println("Circle Circumference: " + circ.getCircumference());
		System.out.println("Circle (180, 390) Is Inside: " + circ.isPointInside(180, 390));*/
		PApplet marker = new PApplet();
		marker.init();
		JFrame window = new JFrame();
		window.setSize(600, 480);
		marker.size(600, 480);
		marker.background(255);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.add(marker);
		circ.changeColor(250, 200, 60);
		circ.grow(50);
		circ.draw(marker);
		rect.changeColor(200, 10, 70);
		rect.lengthen(200);
		rect.draw(marker);
		window.setVisible(true);
	}
}
