import processing.core.PApplet;

/**Represents a circle defined by the radius, color, and x and y coordinates.
 * 
 * @author Ashley Helfinstein
 * @version 9/16/15
 *
 */
public class Circle {
	//fields
	private double x, y;
	private double radius;
	//gives rgb color for circle fill
	private int colorR, colorG, colorB;
	
	
	
	// Creates a default instance of a Circle object with all dimensions
	//  set to zero.
	public Circle(){
		x=0;
		y=0;
		radius=0;
		colorR=255;
		colorG=255;
		colorB=255;
	}
	
	//Creates a new instance of a Circle object with the left and right
	//edges of the circle at x-radius and x+radius. The top and bottom edges
	//are at y-radius and y+radius.
	public Circle(double x, double y, double radius){
		this.x=x;
		this.y=y;
		this.radius=radius;
		colorR=255;
		colorG=255;
		colorB=255;
	}
	
	//Methods
	/**Calculates and returns the circumference of the circle
	 * @return double-the circumference of the circle
	 */
	public double getCircumference(){
		return 2*Math.PI*radius;
	}

	/**Calculates and returns the area of the circle
	 * @return double-the area of the circle
	 */
	public double getArea(){
		return Math.PI*Math.pow(radius, 2);
	}

	/**Determines whether the point x,y is contained inside this circle
	 * 
	 * @param x the x coordinate of the point to be checked
	 * @param y the y coordinate of the point to be checked
	 * @return boolean-whether the given point is inside the circle (not including the edge points)
	 */
	public boolean isPointInside(double x, double y){
		if (x>(this.x-radius) && x<(this.x+radius) && y>(this.y-radius) && y<(this.y+radius)){
			return true;
		}
		else{
			return false;
		}
	}
	
	/**Changes fill color of circle to wantedColor using the RGB values
	 * 
	 * @param wantedColorR the R value of the color to be changed to (in RGB)
	 * @param wantedColorG the G value of the color to be changed to
	 * @param wantedColorB the B value of the color to be changed to
	 * @pre wantedColorR>=0
	 * @pre wantedColorG>=0
	 * @pre wantedColorB>=0
	 */
	public void changeColor(int wantedColorR, int wantedColorG, int wantedColorB){
		colorR=wantedColorR;
		colorG=wantedColorG;
		colorB=wantedColorB;
	}
	
	/**Makes circle larger in both directions-width and height both greater overall by amount
	 * 
	 * @param amount the amount to increase the width and height of the circle (half of it to add to radius)
	 */
	public void grow(int amount){
		radius +=amount/2;
	}

	/** Draws a new instance of a Circle object with the left and right
	 * edges of the circle at x-radius and x+radius. The top and bottom edges
	 * are at y-radius and y+radius.
	 * 
	 * @param marker the PApplet that can draw the circle on the screen 
	 * @post the marker has some state changes. the size is (600, 480), the background is white, the stroke is black, and the fill is the color set in changeColor()
	 */
	public void draw(PApplet marker){
		marker.size(600, 480);
		marker.background(255);
		marker.stroke(0);
		//fills circle with desired color-white is default
		marker.fill(colorR, colorG, colorB);
		marker.ellipse((float)x, (float)y, (float)radius*2, (float)radius*2);
	}


}

