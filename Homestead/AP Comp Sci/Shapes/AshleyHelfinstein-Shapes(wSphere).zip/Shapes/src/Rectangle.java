import processing.core.PApplet;

/**Represents a rectangle defined by its color, width and height, and x and y coordinates.
 * 
 * @author Ashley Helfinstein
 * @version 9/16/15
 *
 */
public class Rectangle { 
	//fields
	private double x, y;
	private double width, height;
	//gives rgb color for rectangle fill
	private int colorR, colorG, colorB;
	
	
	
	// Creates a default instance of a Rectangle object with all dimensions
	//  set to zero.
	public Rectangle(){
		x=0;
		y=0;
		width=0;
		height=0;
		colorR=255;
		colorG=255;
		colorB=255;
	}
	
	//Creates a new instance of a Rectangle object with the left and right
	//edges of the rectangle at x and x + width. The top and bottom edges
	//are at y and y + height.
	public Rectangle(double x, double y, double width, double height){
		this.x=x;
		this.y=y;
		this.width=width;
		this.height=height;
		colorR=255;
		colorG=255;
		colorB=255;
	}
	
	//Methods
	
	/**Calculates and returns the perimeter of the rectangle
	 * 
	 * @return double-the perimeter of the rectangle
	 */
	public double getPerimeter(){
		return 2*width + 2*height;
	}

	/**Calculates and returns the area of the rectangle
	 * 
	 * @return double-the area of the rectangle
	 */
	public double getArea(){
		return width*height;
	}

	/**Determines whether the point x,y is contained inside this rectangle
	 * 
	 * @param x the x coordinate of the point to check if it's inside the rectangle
	 * @param y the y coordinate of the point to check if it's inside the rectangle
	 * @return boolean-whether the given point is inside the rectangle (edges not included)
	 */
	public boolean isPointInside(double x, double y){
		if (x>this.x && x<(this.x+width) && y>this.y && y<(this.y+height)){
			return true;
		}
		else{
			return false;
		}
	}
	
	/**changes fill color of rectangle to wantedColor
	 * 
	 * @param wantedColorR the R value of the color to be changed to (in RGB)
	 * @param wantedColorG the G value of the color to be changed to
	 * @param wantedColorB the B value of the color to be changed to
	 * @pre wantedColorR>=0
	 * @pre wantedColorG>=0
	 * @pre wantedColorB>=0
	 */
	public void changeColor(int wantedColorR, int wantedColorG, int wantedColorB){
		colorR=wantedColorR;
		colorG=wantedColorG;
		colorB=wantedColorB;
	}
	
	/**makes rectangle longer horizontally
	 * 
	 * @param amount the amount to add to the length of the rectangle (negative values decrease the length) 
	 */
	public void lengthen(int amount){
		width +=amount;
	}

	/**Draws a new instance of a Rectangle object with the left and right
	// edges of the rectangle at x and x + width. The top and bottom edges
	// are at y and y + height.
	 * 
	 * @param marker the PApplet that can draw the rectangle on the screen
	 * @post marker has some state changes. The size is set to (600, 480), the background is white, the stroke color is black, and the fill color is the color set by changeColor()
	 */
	public void draw(PApplet marker){
		marker.size(600, 480);
		marker.background(255);
		marker.stroke(0);
		//fills rectangle with desired color-white is default
		marker.fill(colorR, colorG, colorB);
		marker.rect((float)x, (float)y, (float)width, (float)height);
	}


}
