import processing.core.PApplet;

/**Represents a line defined by the x and y coordinates of the two endpoints of the line.
 * 
 * @author Ashley Helfinstein
 * @version 9/16/15
 *
 */
public class Line { 
	//fields
	private double firstPointX, firstPointY, lastPointX, lastPointY;
	private double intersectX, intersectY;
	
	
	//constructor
	// Constructs a line from (x1, y1) to (x2, y2)
	public Line(double x1, double y1, double x2, double y2){
		firstPointX=x1;
		firstPointY=y1;
		lastPointX=x2;
		lastPointY=y2;
	}
	
	//methods
	
	/** Sets this line's second point (x2, y2) to a new coordinate
	 * 
	 * @param x2 the new x coordinate of the second endpoint of the line
	 * @param y2 the new y coordinate of the second endopint of the line
	 */
	public void setPoint2(double x2, double y2){
		lastPointX=x2;
		lastPointY=y2;
	}
	/**Draws this line using the PApplet passed as an argument
	 * 
	 * @param drawer the PApplet that can draw the line on the screen
	 */
	public void draw(PApplet drawer){
		drawer.line((float)firstPointX, (float)firstPointY, (float)lastPointX, (float)lastPointY);
	}
	//BONUS
	/**finds the x coordinate of the circle to be drawn at the intersection point
	 * 
	 * @param other the other line that might intersect the line the method is called on 
	 * @pre other!= null
	 * @return double-the x coordinate of the intersection of the two lines (where the circle will later be drawn)
	 */
	public double findCircleX(Line other){
		double bottom = (firstPointX-lastPointX)*(other.firstPointY-other.lastPointY)-(firstPointY-lastPointY)*(other.firstPointX-other.lastPointX);
		intersectX = ((firstPointX*lastPointY - firstPointY*lastPointX)*(other.firstPointX-other.lastPointX)-(firstPointX-lastPointX)*(other.firstPointX*other.lastPointY-other.firstPointY*other.lastPointX))/bottom;
		return intersectX;
	}
	/**finds the y coordinate of the intersection point
	 * 
	 * @param other the other line that might intersect the line the method is called on 
	 * @pre other != null
	 * @return double-the y coordinate of the intersection of the two lines
	 */
	public double findCircleY(Line other){
		double bottom = (firstPointX-lastPointX)*(other.firstPointY-other.lastPointY)-(firstPointY-lastPointY)*(other.firstPointX-other.lastPointX);
		intersectY = ((firstPointX*lastPointY - firstPointY*lastPointX)*(other.firstPointY-other.lastPointY)-(firstPointY-lastPointY)*(other.firstPointX*other.lastPointY-other.firstPointY*other.lastPointX))/bottom;
		return intersectY;
	}
	

	/**Returns true if this line segment and the segment other intersect each other. Returns false if they do not intersect.
	 * 
	 * @param other the other line with which to check the intersection 
	 * @return boolean-whether the two lines intersect
	 */
	public boolean intersects(Line other){
		boolean line1X1IsSmaller;
		boolean line1Y1IsSmaller;
		boolean line2X1IsSmaller;
		boolean line2Y1IsSmaller;
		
		if(firstPointX<lastPointX){
			line1X1IsSmaller=true;
		}
		else{
			line1X1IsSmaller=false;
		}
		if(firstPointY<lastPointY){
			line1Y1IsSmaller=true;
		}
		else{
			line1Y1IsSmaller=false;
		}
		if(other.firstPointX<other.lastPointX){
			line2X1IsSmaller=true;
		}
		else{
			line2X1IsSmaller=false;
		}
		if(other.firstPointY<other.lastPointY){
			line2Y1IsSmaller=true;
		}
		else{
			line2Y1IsSmaller=false;
		}
		
		double bottom = (firstPointX-lastPointX)*(other.firstPointY-other.lastPointY)-(firstPointY-lastPointY)*(other.firstPointX-other.lastPointX);
		intersectX = ((firstPointX*lastPointY - firstPointY*lastPointX)*(other.firstPointX-other.lastPointX)-(firstPointX-lastPointX)*(other.firstPointX*other.lastPointY-other.firstPointY*other.lastPointX))/bottom;
		intersectY = ((firstPointX*lastPointY - firstPointY*lastPointX)*(other.firstPointY-other.lastPointY)-(firstPointY-lastPointY)*(other.firstPointX*other.lastPointY-other.firstPointY*other.lastPointX))/bottom;
		//checks if denominator is 0 (lines are parallel)
		if (Math.abs(bottom-0.0) < 0.0000001){
			return false;
		}
		else if(line1X1IsSmaller){
			if(intersectX>=firstPointX && intersectX<=lastPointX){
				if(line1Y1IsSmaller){
					if(intersectY>=firstPointY && intersectY<=lastPointY){
						if(line2X1IsSmaller){
							if(intersectX>=other.firstPointX && intersectX<=other.lastPointX){
								if(line2Y1IsSmaller){
									if(intersectY>=other.firstPointY && intersectY<=other.lastPointY){
										return true;
									}
									else{
										return false;
									}
								}	
								else{
									if(intersectY<=other.firstPointY && intersectY>=other.lastPointY){
										return true;
									}
									else{
										return false;
									}
								}
							}
							else{
								return false;
							}
						}
						else{
							if(intersectX<=other.firstPointX && intersectX>=other.lastPointX){
								if(line2Y1IsSmaller){
									if(intersectY>=other.firstPointY && intersectY<=other.lastPointY){
										return true;
									}
									else{
										return false;
									}
								}	
								else{
									if(intersectY<=other.firstPointY && intersectY>=other.lastPointY){
										return true;
									}
									else{
										return false;
									}
								}
							}
							else{
								return false;
							}
						}
					}
					else{
						return false;
					}
				}
				else{
					if(intersectY<=firstPointY && intersectY>=lastPointY){
						if(line2X1IsSmaller){
							if(intersectX>=other.firstPointX && intersectX<=other.lastPointX){
								if(line2Y1IsSmaller){
									if(intersectY>=other.firstPointY && intersectY<=other.lastPointY){
										return true;
									}
									else{
										return false;
									}
								}	
								else{
									if(intersectY<=other.firstPointY && intersectY>=other.lastPointY){
										return true;
									}
									else{
										return false;
									}
								}
							}
							else{
								return false;
							}
						}
						else{
							if(intersectX<=other.firstPointX && intersectX>=other.lastPointX){
								if(line2Y1IsSmaller){
									if(intersectY>=other.firstPointY && intersectY<=other.lastPointY){
										return true;
									}
									else{
										return false;
									}
								}	
								else{
									if(intersectY<=other.firstPointY && intersectY>=other.lastPointY){
										return true;
									}
									else{
										return false;
									}
								}
							}
							else{
								return false;
							}
						}
					}
					else{
						return false;
					}
				}
			}
			else{
				return false;
			}
		}
		else{
			if(intersectX<=firstPointX && intersectX>=lastPointX){
				if(line1Y1IsSmaller){
					if(intersectY>=firstPointY && intersectY<=lastPointY){
						if(line2X1IsSmaller){
							if(intersectX>=other.firstPointX && intersectX<=other.lastPointX){
								if(line2Y1IsSmaller){
									if(intersectY>=other.firstPointY && intersectY<=other.lastPointY){
										return true;
									}
									else{
										return false;
									}
								}	
								else{
									if(intersectY<=other.firstPointY && intersectY>=other.lastPointY){
										return true;
									}
									else{
										return false;
									}
								}
							}
							else{
								return false;
							}
						}
						else{
							if(intersectX<=other.firstPointX && intersectX>=other.lastPointX){
								if(line2Y1IsSmaller){
									if(intersectY>=other.firstPointY && intersectY<=other.lastPointY){
										return true;
									}
									else{
										return false;
									}
								}	
								else{
									if(intersectY<=other.firstPointY && intersectY>=other.lastPointY){
										return true;
									}
									else{
										return false;
									}
								}
							}
							else{
								return false;
							}
						}
					}
					else{
						return false;
					}
				}
				else{
					if(intersectY<=firstPointY && intersectY>=lastPointY){
						if(line2X1IsSmaller){
							if(intersectX>=other.firstPointX && intersectX<=other.lastPointX){
								if(line2Y1IsSmaller){
									if(intersectY>=other.firstPointY && intersectY<=other.lastPointY){
										return true;
									}
									else{
										return false;
									}
								}	
								else{
									if(intersectY<=other.firstPointY && intersectY>=other.lastPointY){
										return true;
									}
									else{
										return false;
									}
								}
							}
							else{
								return false;
							}
						}
						else{
							if(intersectX<=other.firstPointX && intersectX>=other.lastPointX){
								if(line2Y1IsSmaller){
									if(intersectY>=other.firstPointY && intersectY<=other.lastPointY){
										return true;
									}
									else{
										return false;
									}
								}	
								else{
									if(intersectY<=other.firstPointY && intersectY>=other.lastPointY){
										return true;
									}
									else{
										return false;
									}
								}
							}
							else{
								return false;
							}
						}
					}
					else{
						return false;
					}
				}
			}
			else{
				return false;
			}
		}
				
	}


	
	
}
