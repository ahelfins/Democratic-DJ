import processing.core.PApplet;

/**Represents a Sphere defined by its radius and x and y coordinates.
 * 
 * @author Ashley Helfinstein
 * @version 9/18/15
 *
 */
public class Sphere {
	//fields
	private double radius;
	private int x, y, z;
	
	//constructors
	/**Sets up a sphere with a 3D coordinate and radius
	 * 
	 * @param radius the radius of the sphere
	 * @param x the x coordinate of the center of the sphere
	 * @param y the y coordinate of the center of the sphere
	 * @param z the z coordinate of the center of the sphere (3rd dimension)
	 */
	public Sphere(double radius, int x, int y, int z){
		this.radius = radius;
		this.x = x;
		this.y = y;
		this.z = z;
	}
	/**Sets up a default sphere with the values set to zero
	 * 
	 */
	public Sphere(){
		radius = 0;
		x = 0;
		y = 0;
		z = 0;
	}
	//methods
	/**Finds the volume of the sphere
	 * 
	 * @return double-the volume of the sphere
	 */
	public double findVolume(){
		return Math.PI*Math.pow(radius, 3)*4/3;
	}
	/**Finds the surface area of the sphere
	 * 
	 * @return double-the surface area of the sphere
	 */
	public double findSurfaceArea(){
		return 4*Math.PI*Math.pow(radius, 2);
	}
	/**Returns the current radius of the sphere
	 * 
	 * @return double-the radius of the sphere
	 */
	public double getRadius(){
		return radius;
	}
	/**Determines whether the given point is inside the sphere
	 * 
	 * @param x the x coordinate of the point to check if inside the sphere
	 * @param y the y coordinate of the point to check 
	 * @param z the z coordinate of the point to check 
	 * @return boolean-whether the point is inside the sphere
	 */
	public boolean isPointInside(int x, int y, int z){
		if(x>this.x-radius && x<this.x+radius && y>this.y-radius && y<this.y+radius && z>this.z-radius && z<this.z+radius){
			return true;
		}
		else{
			return false;
		}
	}
	/**Sets the location of the center of the sphere to the given point
	 * 
	 * @param x the x coordinate of the new center point
	 * @param y the y coordinate of the new center
	 * @param z the z coordinate of the new center
	 */
	public void setLocation(int x, int y, int z){
		this.x = x;
		this.y = y;
		this.z = z;
	}
	/**Increases or decreases the radius by a given amount 
	 * 
	 * @pre amount>=-(getRadius())
	 * @param amount the amount by which to change the radius (negative values decrease)
	 */
	public void changeRadius(int amount){
		radius+=amount;
	}
	/**Draws the sphere to the screen using ellipses to show 3 dimensions
	 * 
	 * @param drawer the PApplet that can draw the sphere to the screen
	 * @post The drawer has some state changes. The stroke color will be changed to black. The fill will be white. 
	 */
	public void draw(PApplet drawer){
		drawer.fill(255);
		drawer.stroke(0);
		//draws big circle
		drawer.ellipse(x, y, (float)radius*2, (float)radius*2);
		//gives depth to sphere
		drawer.ellipse(x, y, (float)radius*2, (float)radius/2);
	}
	
}
