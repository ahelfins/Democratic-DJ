import java.util.Scanner;

public class Main {
	public static void main(String args[]) {
		Scanner s = new Scanner(System.in);
		TaxApplicant person; 
		
		int maritalStatus;
		System.out.println("Enter marital status (1=single, 2=married): ");
		maritalStatus=s.nextInt();
		int money;
		System.out.println("Enter taxable income: ");
		money=s.nextInt();
		
		person = new TaxApplicant(maritalStatus, money);
		System.out.println("Your Federal tax = " + person.calcTax());
		
		/*a=8100
		 *b=3750
		 *c=89342.15
		 *d=48164.75
		 *e=4500
		 *f=172610.15
		 *g=43097.5
		 *h=8993.75
		 *i=30722.50
		 *j=31252.25
		 */
	}
}
