/**Represents a tax applicant with a given income and marital status
 * 
 * @author Ashley Helfinstein
 * @version 10/5/15
 *
 */
/*
 * a. 9
 * b. 7
 * c. 3
 * d. 5
 * 
 */
public class TaxApplicant {
	private boolean married;
	private int income;
	
	/**Sets up a tax applicant based on marital status and income
	 * 
	 * @param married the int 1 or 2 that represents whether the applicant is married
	 * @param income the income of the tax applicant
	 * @pre married=1 or married=2
	 * @pre income>=0
	 */
	public TaxApplicant(int married, int income){
		this.income=income;
		if(married==1)
			this.married=false;
		else if(married==2)
			this.married=true;
	}
	
	/**Calculates the tax owed by the tax applicant
	 * 
	 * @return double-the tax owed
	 */
	public double calcTax(){
		if(!married){
			if(income<=27050)
				return income*0.15;
			else if(income<=65550)
				return 4057.50+(income-27050)*0.275;
			else if(income<=136750)
				return 14645.00+(income-65550)*0.305;
			else if(income<=297350)
				return 36361.00+(income-136750)*0.355;
			else
				return 93374.00+(income-297350)*0.391;
		}
		else{
			if(income<=45200)
				return income*0.15;
			else if(income<=109250)
				return 6780.00+(income-45200)*0.275;
			else if(income<=166500)
				return 24393.75+(income-109250)*0.305;
			else if(income<=297350)
				return 41855.00+(income-166500)*0.355;
			else
				return 88306.00+(income-297350)*0.391;
		}
	}
}
