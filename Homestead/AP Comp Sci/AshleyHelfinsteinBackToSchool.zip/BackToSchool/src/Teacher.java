
public class Teacher extends Person {
	
	private String mySubject;
	private double mySalary;
	
	public Teacher(String name, int age, String gender, String subject, double salary){
		super(name, age, gender);
		mySubject=subject;
		mySalary=salary;
	}
	
	public String getSubject(){
		return mySubject;
	}
	public void setSubject(String newSubject){
		mySubject=newSubject;
	}
	
	public double getSalary(){
		return mySalary;
	}
	public void setSalary(double newSalary){
		mySalary=newSalary;
	}
	
	public String toString(){
		return super.toString()+", subject taught: " + mySubject + ", salary: "+mySalary;
		
	}
}
