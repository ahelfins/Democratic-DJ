import java.util.Scanner;


public class RecursiveStringTools {
	
	// Example given in reading
	public int length(String in) {
		if (in.isEmpty() ) 
		      return 0;
		    else
		      return 1 + length(in.substring(1));
	}
	
	
	// Example given in reading	
	public boolean equals(String in1, String in2) {
		if (in1.isEmpty() && in2.isEmpty() ) 
		      return true;
		    else if (in1.isEmpty() || in2.isEmpty() ) 
		      return false;
		    else if (in1.charAt(0) != in2.charAt(0) )
		      return false;
		    else
		      return equals(in1.substring(1), in2.substring(1));
	}
	


	// Example given in reading
	public String reverse(String in) {
		
	    if (in.isEmpty() ) 
	      return "";
	    else 
	      return reverse(in.substring(1)) + in.charAt(0);
		  
	}
	

	
	// Exercise #1
	public static boolean matches(String in1, String in2) {
		if(in1.isEmpty()&&in2.isEmpty()){
			return true;
		}
		else if(in1.isEmpty()||in2.isEmpty()){
			return false;
		}
		else if(in1.charAt(0)=='?'||in2.charAt(0)=='?'){
			return matches(in1.substring(1),in2.substring(1));
		}
		else if(in1.charAt(0)==in2.charAt(0)){
			return matches(in1.substring(1),in2.substring(1)); 
		}
		else{
			return false;
		}
	}
	
	

	// Exercise #2
	public static boolean isPalindrome(String in) {
		String other=in.toLowerCase();
		for(;!other.isEmpty()&&!Character.isLetterOrDigit(other.charAt(0));other=other.substring(1)){
			
		}
		for(;!other.isEmpty()&&!Character.isLetterOrDigit(other.charAt(other.length()-1));other=other.substring(0,other.length()-1)){
			
		}
		if(other.isEmpty()){
			return true;
		}
		else if(other.length()==1){
			return true;
		}
		if(other.charAt(0)==other.charAt(other.length()-1)){
			return isPalindrome(other.substring(1, other.length()-1));
		}
		else{
			return false;
		}
	}
	
	

	// Exercise #3
	public static void printPermutations(String in) {
		findPermutations("", in);	
	}
	private static void findPermutations(String start, String in){
		if(in.isEmpty()){
			System.out.println(start);
		}
		else{
			for(int i=0; i<in.length(); i++){
				char letter=in.charAt(i);
				findPermutations(start+letter, in.substring(0,i)+in.substring(i+1));
			}
		}
	}
	
	//other way 
	/*private static String[] findPermutations(String in){
		String[] permutations=new String[(int)factorial(in.length())];
		if(in.length()==1){
			permutations[0]=in;
		}
		else{
			int pNum=0;
			char c=in.charAt(0);
			String[] sub=findPermutations(in.substring(1));
			for(int i=0; i<sub.length; i++){
				for(int x=0; x<=sub[i].length(); x++){
					String start=sub[i].substring(0, x);
					String end;
					if(x<sub[i].length()){
						end=sub[i].substring(x);
					}
					else{
						end="";
					}
					permutations[pNum]=start+c+end;
					pNum++;
				}
			}
		}
		return permutations;
	}
	*/
	
	//BONUS
	public static String piglatinate(String in){
		String result="";
		String word="";
		char c;
		for(int i=0; i<in.length();i++){
			c=in.charAt(i);
			if(Character.isLetterOrDigit(c)){
				word=word+in.charAt(i);
			}
			else{
				if(word.isEmpty()){
					result+=c;
				}
				else{
					String pigWord=findPigL("",word);
					result+=pigWord+c;
					word="";
				}
			}
			
		}
		if(!word.isEmpty()){
			String pigWord=findPigL("",word);
			result+=pigWord;
		}
		return result;
	}
	private static String findPigL(String start, String in) {
		String end=in; 
		if(end.isEmpty()){
			return start+"ay";
		}
		char letter=end.charAt(0);
		char lowerCaseLetter=Character.toLowerCase(letter);
		if(lowerCaseLetter=='a'||lowerCaseLetter=='e'||lowerCaseLetter=='i'||lowerCaseLetter=='o'||lowerCaseLetter=='u'){
			if(start.isEmpty()){
				start="y";
			}
			if(Character.isUpperCase(start.charAt(0))){
				end=Character.toUpperCase(end.charAt(0))+end.substring(1);
				start=Character.toLowerCase(start.charAt(0))+start.substring(1);
			}
			return end + start + "ay";
		}
		else{
			start=start+letter;
			return findPigL(start, end.substring(1));
		}
	}
	
	
	
	public static void main(String[] args) {
		Scanner kboard = new Scanner(System.in);
		System.out.println("Please enter a string!");
		String s = kboard.nextLine();
		
		//printPermutations("luck");
		String result=piglatinate(s);
		//boolean result=isPalindrome(s);
		//boolean result=matches(s, "rattle?????");
		//RecursiveStringTools runner = new RecursiveStringTools();
		//String out = runner.length(s) + "";
		System.out.print("\n\nThe result is --> " + result + "\n\n");
	}
}
