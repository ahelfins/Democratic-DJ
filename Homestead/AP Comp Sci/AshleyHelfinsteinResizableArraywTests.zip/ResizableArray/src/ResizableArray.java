import java.util.Arrays;

public class ResizableArray {
	
	public static final int START_POSSIBLE_VALS = 10;
	private int[] data;
	private int size;
	
	public ResizableArray(){
		data=new int[START_POSSIBLE_VALS];
		size=0;
	}
	
	public ResizableArray(int[] values){
		data=new int[values.length];
		size=values.length;
		for(int i=0; i<values.length; i++)
			data[i]=values[i];
	}
	
	public ResizableArray(ResizableArray other){
		data=new int[other.size()];
		size=other.size();
		for(int i=0; i<size; i++)
			data[i]=other.get(i);
	}
	
	private void resize(){
		int[] temp=new int[data.length+10];
		for(int i=0; i<data.length; i++)
			temp[i]=data[i];
		data=temp;
	}
	
	//first wave
	public void add(int x){
		if(data.length<=size)
			resize();
		data[size]=x;
		size++;
	}
	public int remove(int i){
		if(i>=size || i<0){
			throw new IllegalArgumentException("Bad index: " + i); 
		}
		else{
			int value=data[i];
			for(int y=i; y<size-1; y++){
				data[y]=data[y+1];
			}
			size--;
			return value;
		}
	}
	public int size(){
		return size;
	}
	public String toString(){
		String x="";
		for(int i=0; i<size; i++){
			x+=data[i]+" ";
		}
		return x;
	}
	//second wave
	public void insert(int i, int x){
		if(data.length<=size)
			resize();
		if(i>size || i<0){
			throw new IllegalArgumentException("Bad index: " + i); 
		}
		else{
			size++;
			for(int y=size-1; y>i; y--){
				data[y]=data[y-1];
			}
			data[i]=x;
		}
	}
	public int get(int i){
		if(i>=size || i<0){
			throw new IllegalArgumentException("Bad index: " + i); 
		}
		else{
			return data[i];
		}
	}
	public void set(int i, int x){
		if(i>size || i<0){
			throw new IllegalArgumentException("Bad index: " + i); 
		}
		else{
			data[i]=x;
		}
	}
	public void sort(){
		Arrays.sort(data, 0, size);
	}
	public int indexOf(int x){
		int ans=-1;
		for(int i=0; i<size; i++){
			if(data[i]==x)
				return i;
		}
		return ans;
	}
	public boolean equals(ResizableArray other){
		if(size!=other.size())
			return false;
		for(int i=0; i<size; i++){
			if(data[i]!=other.get(i))
				return false;
		}
		return true;
	}
	public int[] toArray(){
		int[] ans=new int[size];
		for(int i=0; i<size; i++)
			ans[i]=data[i];
		return ans;
	}
	
	//third wave
	public void add(int[] values){
		for(int i=0; i<values.length; i++)
			add(values[i]);
	}
	public void removeAll(int x){
		for(int i=0; i<size; i++){
			if(data[i]==x)
				remove(i);
		}
	}
	public void replaceAll(int x, int with){
		for(int i=0; i<size; i++){
			if(data[i]==x)
				set(i, with);
		}
	}
	//works like substring: start is the index of the start (index included), end is the index of the end (not included)
	public ResizableArray subArray(int start, int end){
		ResizableArray ans = new ResizableArray();
		for(int i=start; i<end; i++){
			ans.add(data[i]);
		}
		return ans;
	}
	public int lastIndexOf(int x){
		int ans=-1;
		for(int i=size-1; i>=0; i--){
			if(data[i]==x)
				return i;
		}
		return ans;
	}
	
	public static void main(String[] args){
		ResizableArray y = new ResizableArray();
		int[] values={3,2,1,4,5,6,7,4,7, 8, 9, 10};
		ResizableArray z = new ResizableArray(values);
		//System.out.println(z);
		ResizableArray w = new ResizableArray(z);
		/*System.out.println(w);
		y.add(6);
		y.add(7);
		y.add(3);
		y.add(5);
		y.remove(1);
		y.insert(2, -100);
		System.out.println(y);
		System.out.println(y.size());
		System.out.println(y.get(2));
		y.set(3, 12);
		System.out.println(y);
		y.sort();
		System.out.println(y);
		System.out.println(y.indexOf(3));
		System.out.println(y.indexOf(7));
		ResizableArray x = new ResizableArray();
		x.add(-100);
		x.add(3);
		x.add(6);
		x.add(12);
		System.out.println(y.equals(x));
		x.add(3);
		System.out.println(y.equals(x));
		x.remove(4);
		x.set(0, 1);
		System.out.println(y.equals(x));
		int[] ar=y.toArray();
		for(int i=0; i<y.size(); i++){
			System.out.print(ar[i]+" ");
		}
		x.add(ar);
		System.out.println("\n" +x);
		x.removeAll(3);
		System.out.println(x);
		x.replaceAll(6, 2);
		System.out.println(x);
		System.out.println(x.lastIndexOf(12));
		System.out.println(x.subArray(1, 5));
		/*y.add(8);
		y.add(8);
		y.add(8);
		y.add(8);
		y.add(8);
		y.add(8);
		System.out.println(y);
		System.out.println(y.size());
		y.add(0);
		System.out.println(y);
		System.out.println(y.size());
		/*y.add(1);
		y.add(2);
		y.add(4);
		y.add(5);
		System.out.println(y.size()+"");
		System.out.println(y.toString());
		y.insert(2, 3);
		System.out.println(y.size()+"");
		System.out.println(y.toString());
		y.remove(4);
		System.out.println(y.size()+"");
		System.out.println(y.toString());*/

	}
	
	
}


