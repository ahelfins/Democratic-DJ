import java.util.ArrayList;

public class Main {
	
	public static void main(String[] args){
		FileIO reader = new FileIO();
		String fileSep = System.getProperty("file.separator");
		ArrayList<String> fileData1 = reader.readData("data" + fileSep + "u.user");
		ArrayList<String> fileData2 = reader.readData("data" + fileSep + "u.item");
		ArrayList<String> fileData3 = reader.readData("data" + fileSep + "u.data");
		ArrayList<User> usersDatabase = new ArrayList<User>();
		ArrayList<Movie> moviesDatabase = new ArrayList<Movie>();
		ArrayList<Rating> ratingsDatabase = new ArrayList<Rating>();
		 
		for (String s: fileData1){
			User newUser = MovieLens100kTranslator.lineToUser(s);
			usersDatabase.add(newUser);
		}
		for (String s: fileData2){
			Movie newMovie = MovieLens100kTranslator.lineToMovie(s);
			moviesDatabase.add(newMovie);
		}
		for (String s: fileData3){
			Rating newRating = MovieLens100kTranslator.lineToRating(s, usersDatabase, moviesDatabase);;
			ratingsDatabase.add(newRating);
		}
		
		/*for(User u: usersDatabase){
			System.out.println(u);
		}
		for(Movie m: moviesDatabase){
			System.out.println(m);
		}*/
		for(Rating r: ratingsDatabase){
			System.out.println(r);
		}
		
		
	}
	
}
