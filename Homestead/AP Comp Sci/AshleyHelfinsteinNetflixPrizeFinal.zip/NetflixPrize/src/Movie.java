import java.util.ArrayList;
import java.util.Date;

public class Movie {
	private ArrayList<String> genres;
	//private ArrayList<Rating> ratings;
	private long ID;
	private String title;
	private int releaseYear;
	
	public Movie(long ID, String title, int releaseYear, ArrayList<String> genres){
		this.ID=ID;
		this.title=title;
		this.releaseYear=releaseYear;
		this.genres = genres;
	}
	
	public long getID(){
		return ID;
	}
	
	public String toString(){
		String ans="Movie ID: "+ID+", Title: "+title+", Year Released: "+releaseYear+", Genres: ";
		for(int i=0; i<genres.size(); i++)
			ans+=genres.get(i)+" ";
		return ans;
	}
	
}
