
public class User {
	private String occupation; 
	private long ID;
	private char gender;
	private int age;
	private String zip;
	
	private double avgRat;
	private long numRat;
	
	public User(long ID, int age, char gender, String occupation, String zip){
		this.ID=ID;
		this.age=age;
		this.gender=gender;
		this.occupation=occupation;
		this.zip=zip;
		avgRat=0;
		numRat=0;
	}
	
	public long getID(){
		return ID;
	}
	public int getAge(){
		return age;
	}
	public char getGender(){
		return gender;
	}
	public String getZip(){
		return zip;
	}
	
	public double getAvgRat(){
		return avgRat;
	}
	public void addRat(double rating){		
		avgRat=(avgRat*numRat+rating)/(numRat+1);
		numRat++;
		
	}
	
	public String toString(){
		String gen;
		if(gender=='M')
			gen="male";
		else if(gender=='F')
			gen="female";
		else
			gen=""+gender;
				
		String ans= "ID: "+ID+", Age: "+age+", Gender: "+gen+", Occupation: " +occupation+", Zip Code: "+zip;
		return ans;
	}
}
