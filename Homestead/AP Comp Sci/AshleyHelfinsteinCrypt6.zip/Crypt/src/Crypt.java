import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * 
 * This class encrypts and decrypts text files using one of 3 algorithms:
 * 		Random monoalphabet, Vigenere, or Playfair
 * 
 * 
 * @author Ashley Helfinstein
 * @version 3/8/16
 * 
 */
public class Crypt {

	
	/**
	 * 
	 * An integer representing the algorithm chosen.
	 * Set to:
	 * 1 for random monoalphabet
	 * 2 for Vigenere
	 * 3 for Playfair
	 * 
	 */
	
	public static String lineSeparator = System.getProperty("line.separator");
	public static final int algorithm = 3;
	
	
	/**
	 * Reads from the file specified, and writes out an encrypted version of the file. If the output file already
	 * exists, overwrite it.
	 * 
	 * @param inputFilename The path of the file to be encrypted.
	 * @param outputFilename The path of the encrypted file to be saved.
	 * @param keyword The keyword to be used in the encryption algorithm.
	 * 
	 */
	public void encrypt(String inputFilename, String outputFilename, String keyword) 
	{
		helperCrypt(inputFilename, outputFilename, keyword);
	
	}
	
	
	/**
	 * Reads from the (previously encrypted) file specified, and writes out a decrypted version of the file. 
	 * If the output file already exists, overwrite it.
	 * 
	 * @param inputFilename The path of the encrypted file.
	 * @param outputFilename The path of the decrypted file to be saved.
	 * @param keyword The keyword to be used in the decryption algorithm.
	 * 
	 */
	public void decrypt(String inputFilename, String outputFilename, String keyword) 
	{
		helperCrypt(inputFilename, outputFilename, keyword);
	
	}

	private void helperCrypt(String inputFilename, String outputFilename, String keyword){
		File readFile = new File(inputFilename);
		File writeFile = new File(outputFilename);
		
		if(!readFile.exists()){
			System.err.println("File "+inputFilename+" does not exist.");
		}
		
		Scanner in = null;
		FileWriter writer = null;
		BufferedReader bReader = null; 
		BufferedWriter bWriter = null;
		
		
		try{
			FileReader reader = new FileReader(readFile);
			writer = new FileWriter(writeFile);
			bReader = new BufferedReader(reader); 
			bWriter = new BufferedWriter(writer);
			
			
			in=new Scanner(bReader);
			
			StringBuffer alpha=new StringBuffer("abcdefghiklmnopqrstuvwxyz");
			StringBuffer encrypted=new StringBuffer();
			char[][] playfair = new char[5][5];
			StringBuffer key=new StringBuffer(keyword);
			for(int i=0; i<key.length(); i++){
				int ind=key.indexOf(""+key.charAt(i), i+1);
				if(ind!=-1){
					key.deleteCharAt(ind);
					i--;
				}
			}
			for(int m=0; m<key.length(); m++){
				if(key.charAt(m)=='j')
					key.setCharAt(m, 'i');
				if(key.charAt(m)=='J')
					key.setCharAt(m, 'I');
			}
			for(int i=key.length()-1; i>=0; i--){
				int ind=alpha.indexOf(""+key.charAt(i));
				alpha.deleteCharAt(ind);	
				alpha.insert(0, key.charAt(i));
			}
			int count=0;
			for(int i=0; i<playfair.length; i++){
				for(int j=0; j<playfair[i].length; j++){
					playfair[i][j]=alpha.charAt(count);
					count++;
				}
			}
			
			boolean isOdd=false;
			char nextFirst=' ';
			StringBuffer nextMiddle=new StringBuffer();
			StringBuffer nextBefore=new StringBuffer();
			while(in.hasNextLine()){
				StringBuffer input=new StringBuffer(in.nextLine());
				int index1=input.indexOf("j");
				int index2=input.indexOf("J");
				while(index1!=-1||index2!=-1){
					if(index1!=-1){
						input.setCharAt(index1, 'i');
						index1=input.indexOf("j", index1+1);
					}
					if(index2!=-1){
						input.setCharAt(index2, 'I');
						index2=input.indexOf("J", index2+1);
					}
					
				}
					
				for(int i=0; i<input.length(); i+=2){
					char first;
					char second;
					boolean eol=false;
					boolean caps1=false;
					boolean caps2=false;
					StringBuffer before=new StringBuffer();
					StringBuffer middle=new StringBuffer();
					StringBuffer after=new StringBuffer();
					
					if(isOdd){
						first=nextFirst;
						before = nextBefore;
						middle = nextMiddle;
						middle.append(lineSeparator);
						i--;
						isOdd=false;
					}
					else{
						first=input.charAt(i);
					}
					
					while(!Character.isLetter(first)){
						before.append(first);
						i++;
						if(i>=input.length()){
							eol=true;
							encrypted.append(before.toString());
							break;
						}
						first=input.charAt(i);
					}
					if(eol){
						eol=false;
						break;
					}
					if(Character.isUpperCase(first)){
						caps1=true;
					}
					if(i+1>=input.length()){
						if(!in.hasNextLine()){
							second='i';
						}
						else{
							isOdd=true;
							nextBefore=before;
							nextFirst=first;
							nextMiddle=middle;
							break;
						}
					}
					else{
						second=input.charAt(i+1);
						while(!Character.isLetter(second)){
							i++;
							if(i+1>=input.length()){
								if(!in.hasNextLine()){
									after.append(second);
									second='i';
								}
								else{
									isOdd=true;
									nextBefore=before;
									nextFirst=first;
									nextMiddle=middle.append(second);
									eol=true;
									break;
								}
							}
							else{
								middle.append(second);
								second=input.charAt(i+1);
							}	
						}
						if(eol){
							eol=false;
							break;
						}
						if(Character.isUpperCase(second)){
							caps2=true;
						}
					}
					int ind1=alpha.indexOf(""+Character.toLowerCase(first));
					int ind2=alpha.indexOf(""+Character.toLowerCase(second));
					int row1, col1, row2, col2;
					row1=ind1/5;
					col1=ind1%5;
					row2=ind2/5;
					col2=ind2%5;
					int numCols=Math.abs(col1-col2);
					char enc1, enc2;
					if(col1>col2){
						enc1=playfair[row1][col1-numCols];
						enc2=playfair[row2][col2+numCols];
					}
					else if(col1==col2){
						enc1=playfair[row2][col1];
						enc2=playfair[row1][col2];
					}	
					else{
						enc1=playfair[row1][col1+numCols];
						enc2=playfair[row2][col2-numCols];
					}
					if(caps1)
						enc1=Character.toUpperCase(enc1);
					if(caps2)
						enc2=Character.toUpperCase(enc2);
					encrypted.append(before.toString()+enc1+middle.toString()+enc2+after.toString());
				}
				if(isOdd){
					if(input.length()==0)
						nextMiddle.append(lineSeparator);
				}	
				else{
					encrypted.append(lineSeparator);
				}
			}
			bWriter.flush();
			String dataToWrite=encrypted.toString();
			bWriter.write(dataToWrite);
		}
		catch(IOException ex){
			ex.printStackTrace();
		}
		finally{
			if(in != null)
				in.close();
			if(bWriter != null)	
				try {
					bWriter.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
}
