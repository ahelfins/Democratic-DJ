import java.util.Scanner;

public class Main {
	public static void main(String args[]) {
		Scanner s = new Scanner(System.in);
		TaxApplicant person; 
		
		int maritalStatus;
		System.out.println("Enter marital status (1=single, 2=married): ");
		maritalStatus=s.nextInt();
		int money;
		System.out.println("Enter taxable income: ");
		money=s.nextInt();
		
		person = new TaxApplicant(maritalStatus, money);
		System.out.println("Your Federal tax = " + person.calcTax());
		
		/*a=20530
		 *b=3750
		 *c=205606
		 *d=96711
		 *e=4500
		 *f=288874
		 *g=102205
		 *h=16432.50
		 *i=64043.75
		 *j=51245
		 */
	}
}
