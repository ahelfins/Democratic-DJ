import processing.core.PApplet;

public class CollegeStudent extends Student {
	private String myMajor;
	private int myYear;
	//FROSH=1, SOPH=2, JUNIOR=3, SENIOR=4
	
	public CollegeStudent(String name, int age, String gender,
            String idNum, double gpa, int year, String major){
		super(name, age, gender, idNum, gpa);
		myMajor=major;
		myYear=year;
	}
	
	public CollegeStudent(String name, int age, String gender,
            String idNum, double gpa, int year, String major, int xLoc, int yLoc){
		super(name, age, gender, idNum, gpa, xLoc, yLoc);
		myMajor=major;
		myYear=year;
	}
	
	public void draw(PApplet marker) {  
		super.draw(marker);
		marker.fill(10, 94, 4);
		marker.rect(x+50, y+45, 10, 15, 4); //coffee cup
		marker.fill(255); //reset fill color to white
	}
	
	public String getMajor(){
		return myMajor;
	}
	public void setMajor(String major){
		myMajor=major;
	}
	
	public int getYear(){
		return myYear;
	}
	public void setYear(int year){
		myYear=year;
	}
	
	public String toString(){
		return super.toString() + ", year: " + myYear + ", major: " + myMajor;
	}
}
