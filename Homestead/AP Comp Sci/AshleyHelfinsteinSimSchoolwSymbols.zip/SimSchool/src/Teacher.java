import processing.core.PApplet;

public class Teacher extends Person {
	
	private String mySubject;
	private double mySalary;
	
	public Teacher(String name, int age, String gender, String subject, double salary){
		super(name, age, gender);
		mySubject=subject;
		mySalary=salary;
	}
	
	public Teacher(String name, int age, String gender, String subject, double salary, int xLoc, int yLoc){
		super(name, age, gender, xLoc, yLoc);
		mySubject=subject;
		mySalary=salary;
	}
	
	public void draw(PApplet marker) {  
		super.draw(marker);
		marker.ellipse(x+17, y+20, 10, 10);//glasses
		marker.ellipse(x+33, y+20, 10, 10);//glasses
		marker.line(x+22, y+20, x+28, y+20);//glasses
		marker.fill(255, 0, 0);
		marker.stroke(255, 0, 0);
		marker.ellipse(x+55, y+55, 20, 20); //apple
		marker.stroke(111, 52, 52);
		marker.strokeWeight(5);
		marker.line(x+55, y+45, x+55, y+40); //apple stem
		marker.stroke(0); //reset stroke color 
		marker.strokeWeight(1); //reset stroke weight
	}
	
	public String getSubject(){
		return mySubject;
	}
	public void setSubject(String newSubject){
		mySubject=newSubject;
	}
	
	public double getSalary(){
		return mySalary;
	}
	public void setSalary(double newSalary){
		mySalary=newSalary;
	}
	
	public String toString(){
		return super.toString()+", subject taught: " + mySubject + ", salary: "+mySalary;
		
	}
}
