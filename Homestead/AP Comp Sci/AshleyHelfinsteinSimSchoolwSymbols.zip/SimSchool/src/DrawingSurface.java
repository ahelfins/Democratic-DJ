import java.awt.geom.Point2D;

import processing.core.PApplet;



public class DrawingSurface extends PApplet {
	
	private Person person;
	private Teacher teacher;
	private Student student;
	private CollegeStudent collegeStudent;
	
	private int ANIMATION_TIME = 100;
	private float x,y,time;
	
	public DrawingSurface() {
		person=new Person("Brad", 12, "M", 40, 0);
		teacher=new Teacher("Mike", 60, "M","Chemistry", 30000, 100, 100);
		student=new Student("Angelica", 14, "F", "34555", 4.0, 0, 90);
		collegeStudent=new CollegeStudent("Marcia", 19, "F", "45678*", 3.1, 2, "Anthropology", 50, 10);
	}
	
	// The statements in the setup() function 
	// execute once when the program begins
	public void setup() {
		//size(0,0,PApplet.P3D);
	}
	
	// The statements in draw() are executed until the 
	// program is stopped. Each statement is executed in 
	// sequence and after the last line is read, the first 
	// line is executed again.
	public void draw() { 
		background(255);   // Clear the screen with a white background
		fill(255);
		textAlign(CENTER);
		textSize(12);
		
		if (collegeStudent != null) {
			
			collegeStudent.draw(this);
		
			fill(0);
		}
		if (time > 0) {
			time-=2;
			float size = (float)Math.sin((ANIMATION_TIME-time)/ANIMATION_TIME*Math.PI)*10;
			ellipse(x, y, size, size);
		}

	}
	
	
}










