import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * 
 * This class encrypts and decrypts text files using one of 3 algorithms:
 * 		Random monoalphabet, Vigenere, or Playfair
 * 
 * 
 * @author Ashley Helfinstein
 * @version 3/8/16
 * 
 */
public class Crypt {

	
	/**
	 * 
	 * An integer representing the algorithm chosen.
	 * Set to:
	 * 1 for random monoalphabet
	 * 2 for Vigenere
	 * 3 for Playfair
	 * 
	 */
	public static final int algorithm = 3;
	
	
	/**
	 * Reads from the file specified, and writes out an encrypted version of the file. If the output file already
	 * exists, overwrite it.
	 * 
	 * @param inputFilename The path of the file to be encrypted.
	 * @param outputFilename The path of the encrypted file to be saved.
	 * @param keyword The keyword to be used in the encryption algorithm.
	 * 
	 */
	public void encrypt(String inputFilename, String outputFilename, String keyword) 
	{
		File readFile = new File(inputFilename);
		File writeFile = new File(outputFilename);
		
		if(!readFile.exists()){
			System.err.println("File "+inputFilename+" does not exist.");
		}
		
		Scanner in = null;
		FileWriter writer = null;
		
		try{
			FileReader reader = new FileReader(readFile);
			writer = new FileWriter(writeFile);
			BufferedReader bReader = new BufferedReader(reader); 
			BufferedWriter bWriter = new BufferedWriter(writer);
			
			
			in=new Scanner(bReader);
			
			//StringBuffer text = new StringBuffer(readData(inputFilename));
			StringBuffer alpha=new StringBuffer("abcdefghiklmnopqrstuvwxyz");
			StringBuffer encrypted=new StringBuffer();
			char[][] playfair = new char[5][5];
			StringBuffer key=new StringBuffer(keyword);
			for(int i=0; i<key.length(); i++){
				int ind=key.indexOf(""+key.charAt(i), i+1);
				if(ind!=-1){
					key.deleteCharAt(ind);
					i--;
				}
			}
			for(int m=0; m<key.length(); m++){
				if(key.charAt(m)=='j')
					key.setCharAt(m, 'i');
				if(key.charAt(m)=='J')
					key.setCharAt(m, 'I');
			}
			//System.out.println("Keyword: " + key);
			for(int i=key.length()-1; i>=0; i--){
				int ind=alpha.indexOf(""+key.charAt(i));
				alpha.deleteCharAt(ind);	
				alpha.insert(0, key.charAt(i));
			}
			//System.out.println("Alphabet: "+ alpha+alpha.length());
			int count=0;
			for(int i=0; i<playfair.length; i++){
				for(int j=0; j<playfair[i].length; j++){
					playfair[i][j]=alpha.charAt(count);
					count++;
				}
			}
			
			//print line
			/*for(char[] c: playfair){
				for(char ch: c){
					System.out.print(ch+" ");
				}
				System.out.print('\n');
			}*/
			//boolean firstLine = true;
			boolean isOdd=false;
			char nextFirst=' ';
			StringBuffer nextMiddle=new StringBuffer();
			StringBuffer nextBefore=new StringBuffer();
			while(in.hasNextLine()){
				StringBuffer input=new StringBuffer(in.nextLine());
				/*if (firstLine) {
					System.out.println("LINE: " + input + " " + input.length());
				}*/
				int index1=input.indexOf("j");
				int index2=input.indexOf("J");
				while(index1!=-1||index2!=-1){
					if(index1!=-1){
						input.setCharAt(index1, 'i');
						index1=input.indexOf("j", index1+1);
					}
					if(index2!=-1){
						input.setCharAt(index2, 'I');
						index2=input.indexOf("J", index2+1);
					}
					
				}
				for(int i=0; i<input.length(); i+=2){
					char first;
					char second;
					boolean eol=false;
					boolean caps1=false;
					boolean caps2=false;
					StringBuffer before=new StringBuffer();
					StringBuffer middle=new StringBuffer();
					StringBuffer after=new StringBuffer();
					
					if(isOdd){
						//System.out.println("Next is odd");
						first=nextFirst;
						before = nextBefore;
						middle = nextMiddle;
						//System.out.println("(Middle Pre: "+middle+")");
						middle.append(" \n");
						//System.out.println("(Middle Post: "+middle+")");
						//System.out.println("First: "+first+" Before "+ before+ "Middle "+middle);
					}
					else{
						first=input.charAt(i);
					}
					
					while(!Character.isLetter(first)){
						before.append(first);
						i++;
						/*if (firstLine)
							System.out.println("!isLetter: " + first);*/
						if(i>=input.length()){
							/*if (firstLine) {
								System.out.println("EOF " + before);
								firstLine = false;
							}*/
							eol=true;
							encrypted.append(before.toString()+ "\n");
							break;
						}
						first=input.charAt(i);
					}
					if(eol){
						eol=false;
						break;
					}
					if(Character.isUpperCase(first)){
						caps1=true;
					}
					if(i+1>=input.length()){
						if(!in.hasNextLine()){
							second='i';
							System.out.println("I (no lines left)");
							//System.out.println("No next line");
						}
						else{
							//System.out.println("First is Odd");
							isOdd=true;
							nextBefore=before;
							nextFirst=first;
							nextMiddle=middle;
							break;
						}
					}
					else{
						if(isOdd){
							second=input.charAt(i);
							while(!Character.isLetter(second)){
								i++;
								if(i>=input.length()){
									if(!in.hasNextLine()){
										after.append(second);
										second='i';
										System.out.println("I (no lines left)");
									}
									else{
										//System.out.println("Has next line");
										isOdd=true;
										nextBefore=before;
										nextFirst=first;
										nextMiddle=middle.append(second);
										eol=true;
										break;
									}
								}
								else{
									middle.append(second);
									second=input.charAt(i);
								}	
							}
							if(eol){
								eol=false;
								break;
							}
							isOdd=false;
							//System.out.println("Is Odd: "+isOdd+" Second "+second);
						}
						else{
							second=input.charAt(i+1);
							while(!Character.isLetter(second)){
								i++;
								if(i+1>=input.length()){
									if(!in.hasNextLine()){
										after.append(second);
										second='i';
										System.out.println("I (no lines left)");
									}
									else{
										isOdd=true;
										nextBefore=before;
										nextFirst=first;
										nextMiddle=middle.append(second);
										eol=true;
										break;
									}
								}
								else{
									middle.append(second);
									second=input.charAt(i+1);
								}	
							}
							if(eol){
								eol=false;
								break;
							}
						}
						if(Character.isUpperCase(second)){
							caps2=true;
						}
					}
					/*if(isOdd){
						//System.out.println("Adding new line");
						middle+="\n";
					}*/
					//if (firstLine)
						//System.out.println("First: "+first+" Second: "+second + " Middle " + middle);
					//System.out.println("Caps1: "+caps1+ " Caps2: "+caps2);
					int ind1=alpha.indexOf(""+Character.toLowerCase(first));
					int ind2=alpha.indexOf(""+Character.toLowerCase(second));
					//System.out.println("Ind1: "+ind1+" Ind2: "+ind2);
					int row1, col1, row2, col2;
					row1=ind1/5;
					col1=ind1%5;
					row2=ind2/5;
					col2=ind2%5;
					//System.out.println("Row1: "+row1+ " Row2: "+row2+" Col1: "+col1+" col2: "+col2);
					int numRows=Math.abs(row1-row2);
					int numCols=Math.abs(col1-col2);
					//System.out.println("NumRows: "+numRows+ " NumCols: "+numCols);
					char enc1, enc2;
					if(col1>col2){
						enc1=playfair[row1][col1-numCols];
						enc2=playfair[row2][col2+numCols];
					}
					else if(col1==col2){
						enc1=playfair[row2][col1];
						enc2=playfair[row1][col2];
					}	
					else{
						enc1=playfair[row1][col1+numCols];
						enc2=playfair[row2][col2-numCols];
					}
					if(caps1)
						enc1=Character.toUpperCase(enc1);
					if(caps2)
						enc2=Character.toUpperCase(enc2);
					/*if (firstLine) {
						System.out.println(caps1+" enc1: "+enc1+" "+caps2+" enc2: "+enc2);
					}*/
					//System.out.println("(Middle Final: "+middle.toString()+")");
					//System.out.println(before.toString()+enc1+middle.toString()+enc2+after.toString());
					encrypted.append(before.toString()+enc1+middle.toString()+enc2+after.toString());
					/*if (firstLine) 
						System.out.println("i is " + i);*/
				}
				if(!isOdd){
					encrypted.append('\n');
				}
			}
			bWriter.flush();
			String dataToWrite=encrypted.toString();
			bWriter.write(dataToWrite);//+lineseparator? get property
		}
		catch(IOException ex){
			ex.printStackTrace();
		}
		finally{
			if(in != null)
				in.close();
			if(writer != null)	
				try {
					writer.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	
	}
	
	
	/**
	 * Reads from the (previously encrypted) file specified, and writes out a decrypted version of the file. 
	 * If the output file already exists, overwrite it.
	 * 
	 * @param inputFilename The path of the encrypted file.
	 * @param outputFilename The path of the decrypted file to be saved.
	 * @param keyword The keyword to be used in the decryption algorithm.
	 * 
	 */
	public void decrypt(String inputFilename, String outputFilename, String keyword) 
	{
		File readFile = new File(inputFilename);
		File writeFile = new File(outputFilename);
		
		if(!readFile.exists()){
			System.err.println("File "+inputFilename+" does not exist.");
		}
		
		Scanner in = null;
		FileWriter writer = null;
		
		try{
			FileReader reader = new FileReader(readFile);
			writer = new FileWriter(writeFile);
			BufferedReader bReader = new BufferedReader(reader); 
			BufferedWriter bWriter = new BufferedWriter(writer);
			
			
			in=new Scanner(bReader);
			
			//StringBuffer text = new StringBuffer(readData(inputFilename));
			String alpha="abcdefghiklmnopqrstuvwxyz";
			StringBuffer decrypted=new StringBuffer();
			char[][] playfair = new char[5][5];
			String key=keyword;
			for(int i=0; i<key.length(); i++){
				int ind=key.indexOf(key.charAt(i), i+1);
				if(ind!=-1){
					key=key.substring(0, ind)+key.substring(ind+1);
					i--;
				}
			}
			key=key.replace('j', 'i');
			key=key.replace('J', 'I');
			//System.out.println("Keyword: " + key);
			for(int i=key.length()-1; i>=0; i--){
				int ind=alpha.indexOf(key.charAt(i));
				alpha=key.charAt(i)+alpha.substring(0, ind)+alpha.substring(ind+1);		
			}
			//System.out.println("Alphabet: "+ alpha);
		
			//System.out.println(alpha+alpha.length());
			int count=0;
			for(int i=0; i<playfair.length; i++){
				for(int j=0; j<playfair[i].length; j++){
					playfair[i][j]=alpha.charAt(count);
					count++;
				}
			}
			
			//print line
			/*for(char[] c: playfair){
				for(char ch: c){
					System.out.print(ch+" ");
				}
				System.out.print('\n');
			}*/
			while(in.hasNextLine()){
				String input=in.nextLine();
				//input=input.replace('j', 'i');
				//input=input.replace('J', 'I');
				for(int i=0; i<input.length(); i+=2){
					char first=input.charAt(i);
					char second;
					boolean eol=false;
					boolean caps1=false;
					boolean caps2=false;
					String before="";
					String middle="";
					
					while(!Character.isLetter(first)){
						before+=first;
						i++;
						if(i>=input.length()){
							eol=true;
							break;
						}
						first=input.charAt(i);
					}
					if(eol){
						break;
					}
					if(Character.isUpperCase(first)){
						caps1=true;
					}
					if(i+1>=input.length()){
						second='i';
					}
					else{
						second=input.charAt(i+1);
						while(!Character.isLetter(second)){
							middle+=second;
							i++;
							if(i+1>=input.length()){
								second='i';
							}
							else{
								second=input.charAt(i+1);
							}	
						}
						if(Character.isUpperCase(second)){
							caps2=true;
						}
					}
					//System.out.println("First: "+first+" Second: "+second);
					//System.out.println("Caps1: "+caps1+ " Caps2: "+caps2);
					int ind1=alpha.indexOf(Character.toLowerCase(first));
					int ind2=alpha.indexOf(Character.toLowerCase(second));
					//System.out.println("Ind1: "+ind1+" Ind2: "+ind2);
					int row1, col1, row2, col2;
					row1=ind1/5;
					col1=ind1%5;
					row2=ind2/5;
					col2=ind2%5;
					//System.out.println("Row1: "+row1+ " Row2: "+row2+" Col1: "+col1+" col2: "+col2);
					int numRows=Math.abs(row1-row2);
					int numCols=Math.abs(col1-col2);
					//System.out.println("NumRows: "+numRows+ " NumCols: "+numCols);
					char enc1, enc2;
					if(col1>col2){
						enc1=playfair[row1][col1-numCols];
						enc2=playfair[row2][col2+numCols];
					}
					else if(col1==col2){
						enc1=playfair[row2][col1];
						enc2=playfair[row1][col2];
					}	
					else{
						enc1=playfair[row1][col1+numCols];
						enc2=playfair[row2][col2-numCols];
					}
					if(caps1)
						enc1=Character.toUpperCase(enc1);
					if(caps2)
						enc2=Character.toUpperCase(enc2);
					//System.out.println(caps1+" enc1: "+enc1+" "+caps2+" enc2: "+enc2);
					decrypted.append(before+enc1+middle+enc2);
				}
				decrypted.append('\n');
			}
			bWriter.flush();
			String dataToWrite=decrypted.toString();
			bWriter.write(dataToWrite);//+lineseparator? get property
		}
		catch(IOException ex){
			ex.printStackTrace();
		}
		finally{
			if(in != null)
				in.close();
			if(writer != null)	
				try {
					writer.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	
	}

	
	
}
