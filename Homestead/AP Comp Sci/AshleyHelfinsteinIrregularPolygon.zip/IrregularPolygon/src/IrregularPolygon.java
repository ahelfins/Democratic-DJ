import java.awt.geom.*;  // for Point2D.Double
import java.util.ArrayList;      // for ArrayList
import processing.core.PApplet;	// for Processing

public class IrregularPolygon {
	
	private ArrayList<Point2D.Double> myPolygon;
	
	//x and y represent the x and y coordinates of the first point of the IrregularPolygon
	public IrregularPolygon(){
		myPolygon=new ArrayList<Point2D.Double>();
	}
	
	// public methods
   public void add(Point2D.Double aPoint) { 
	   myPolygon.add(aPoint);
   }

   public void draw(PApplet marker) {  
	   marker.stroke(0);
	   marker.strokeWeight(1);
	   Point2D.Double p1;
	   Point2D.Double p2;
	   for(int i=0; i<myPolygon.size()-1; i++){
		   p1=myPolygon.get(i);
		   p2=myPolygon.get(i+1);
		   marker.line((float)p1.x, (float)p1.y, (float)p2.x, (float)p2.y);
	   }
	   p1=myPolygon.get(myPolygon.size()-1);
	   p2=myPolygon.get(0);
	   marker.line((float)p1.x, (float)p1.y, (float)p2.x, (float)p2.y);
   }

   public double perimeter() { 
	   double perim=0.0;
	   Point2D.Double p1;
	   Point2D.Double p2;
	   for(int i=0; i<myPolygon.size()-1; i++){
		   p1=myPolygon.get(i);
		   p2=myPolygon.get(i+1);
		   perim+=Math.sqrt(Math.pow((p1.x-p2.x), 2)+Math.pow((p1.y-p2.y), 2));
	   }
	   p1=myPolygon.get(myPolygon.size()-1);
	   p2=myPolygon.get(0);
	   perim+=Math.sqrt(Math.pow((p1.x-p2.x), 2)+Math.pow((p1.y-p2.y), 2));
	   return perim;
   }

   public double area() {  
	   double preArea=0.0;
	   Point2D.Double p1;
	   Point2D.Double p2;
	   for(int i=0; i<myPolygon.size()-1; i++){
		   p1=myPolygon.get(i);
		   p2=myPolygon.get(i+1);
		   preArea+=p1.x*p2.y;
		   preArea-=p1.y*p2.x;
	   }
	   p1=myPolygon.get(myPolygon.size()-1);
	   p2=myPolygon.get(0);
	   preArea+=p1.x*p2.y;
	   preArea-=p1.y*p2.x;
	   return Math.abs(preArea/2);
   }
   
   //brainstormed methods
   public void remove(Point2D.Double aPoint){
	   int index=myPolygon.indexOf(aPoint);
	   myPolygon.remove(index);
   }
   public void addDiagonal(PApplet marker, Point2D.Double p1, Point2D.Double p2){
	   marker.line((float)p1.x, (float)p1.y, (float)p2.x, (float)p2.y);
   }
	
	
}

