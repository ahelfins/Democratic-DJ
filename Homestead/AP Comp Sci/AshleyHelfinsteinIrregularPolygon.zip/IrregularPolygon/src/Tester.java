import java.awt.geom.Point2D;
import java.util.ArrayList;

import javax.swing.JFrame;

import processing.core.PApplet;
/**Contains the main method for the program and functions as a tester to draw the shapes
 * 
 * @author Ashley Helfinstein
 * @version 9/27/15
 *
 */
public class Tester {
	public static void main(String args[]) {
		IrregularPolygon ir = new IrregularPolygon();
		
		PApplet marker = new PApplet();
		marker.init();
		JFrame window = new JFrame();
		window.setSize(600, 480);
		marker.size(600, 480);
		marker.background(255);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.add(marker);
		
		ir.add(new Point2D.Double(20, 10));
		ir.add(new Point2D.Double(70, 20));
		ir.add(new Point2D.Double(50, 50));
		ir.add(new Point2D.Double(0, 40));
		ir.add(new Point2D.Double(1,1));
		ir.remove(new Point2D.Double(1,1));
		ir.addDiagonal(marker, new Point2D.Double(20, 10), new Point2D.Double(50, 50));
		ir.draw(marker);
		System.out.println("Irregular Polygon Area: " + ir.area());
		System.out.println("Irregular Polygon Perimeter: " + ir.perimeter());
		
		
		
		window.setVisible(true);
	}
}
