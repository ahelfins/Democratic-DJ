import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class FileIO {

	/*private String text;
	
	public FileIO(String filename){
		text=readData(filename);
	}*/
	
	public ArrayList<String> readData(String fileName){
		
		File readFile = new File(fileName);
		if(!readFile.exists()){
			System.err.println("File "+fileName+" does not exist.");
			return null;
		}
		
		Scanner in = null;
		
		try{
			FileReader reader = new FileReader(readFile); 
			in = new Scanner(reader);
			
			ArrayList<String> fileData = new ArrayList<String>();
			
			while(in.hasNextLine()){
				String input=in.nextLine();
				fileData.add(input);
			}
			
			return fileData;
		}
		catch(IOException ex){
			ex.printStackTrace();
			return null;
		}
		finally{
			if(in != null)
				in.close();
		}
	}
	
	
	
}
