
public class User {
	private String occupation; 
	private long ID;
	private char gender;
	private int age;
	private String zip;
	
	public User(long ID, int age, char gender, String occupation, String zip){
		this.ID=ID;
		this.age=age;
		this.gender=gender;
		this.occupation=occupation;
		this.zip=zip;
	}
	
	public long getID(){
		return ID;
	}
	
	public String toString(){
		String gen;
		if(gender=='M')
			gen="male";
		else if(gender=='F')
			gen="female";
		else
			gen=""+gender;
				
		String ans= "ID: "+ID+", Age: "+age+", Gender: "+gen+", Occupation: " +occupation+", Zip Code: "+zip;
		return ans;
	}
}
