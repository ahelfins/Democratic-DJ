import info.gridworld.actor.Bug;

public class DancingBug extends Bug {
	
	private int[] turns;
	private int number;
	
	public DancingBug(int[] dance){
		turns=dance;
		number=0;
	}
	
	public void act(){
		for(int i=0; i<turns[number]; i++){
			turn();
		}	
		super.act();
		number++;
		if(number>=turns.length)
			number=0;
	}
}
