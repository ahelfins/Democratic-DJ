
import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.Location;

import java.awt.Color;

/**
 * This class runs a world that contains Dancing bugs. <br />
 * This class is not tested on the AP CS A and AB exams.
 */
public class DancingBugRunner {
	
    public static void main(String[] args)
    {
        ActorWorld world = new ActorWorld();
        //shelby dance
        int[] turns = new int[8];
        turns[0]=1;
        turns[1]=2;
        turns[2]=2;
        turns[3]=3;
        turns[4]=3;
        turns[5]=2;
        turns[6]=2;
        turns[7]=1;
        DancingBug mark = new DancingBug(turns);
        world.add(new Location(5, 5), mark);
        world.show();
    }
	
}

