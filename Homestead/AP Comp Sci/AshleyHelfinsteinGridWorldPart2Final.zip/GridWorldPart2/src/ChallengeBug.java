import info.gridworld.actor.Actor;
import info.gridworld.actor.Bug;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

public class ChallengeBug extends Bug {
		
		private int turns;
		
		public ChallengeBug(){
			turns=0;
		}
		
		public boolean wantsToMove(){
			Grid<Actor> gr = getGrid();
	        if (gr == null)
	            return false;
	        Location loc = getLocation();
	        Location next = loc.getAdjacentLocation(getDirection());
	        Actor neighbor = gr.get(next);
	        return (neighbor == null);
		}
		public boolean hasToMove(){
			if(turns>=8)
				return true;
			else
				return false;
		}
		
		public void act(){
			if(canMove()&&wantsToMove()){
				move();
				turns=0;
			}
			else if(canMove()&&hasToMove()){
				move();
				turns=0;
			}
			else{
				turn();
				turns++;
			}
		}

}
