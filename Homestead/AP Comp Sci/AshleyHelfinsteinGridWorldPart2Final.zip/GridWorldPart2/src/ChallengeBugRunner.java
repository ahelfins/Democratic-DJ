import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Flower;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Location;


public class ChallengeBugRunner {

	    public static void main(String[] args)
	    {
	    	 ActorWorld world = new ActorWorld();
	         ChallengeBug ash = new ChallengeBug();
	         world.add(new Location(5, 5), ash);
	         world.add(new Rock());
	         world.add(new Rock());
	         world.add(new Flower());
	         world.show();
	    }
	

}
