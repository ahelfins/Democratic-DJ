
public class Rating {
	private User user;
	private Movie movie;
	private double stars;
	
	public Rating(User user, Movie movie, double stars){
		this.user = user;
		this.movie = movie;
		this.stars = stars;
	}
	
	public String toString(){
		String ans= "User ID: "+user.getID()+", Movie ID: "+movie.getID()+", Number of Stars: "+stars;
		return ans;
	}
}
