import java.util.ArrayList;

public class MovieLens100kTranslator {
	
	public static User lineToUser(String line){
		String[] entities = line.split("\\|");
		User u = new User(Long.parseLong(entities[0]), Integer.parseInt(entities[1]), entities[2].charAt(0), entities[3], entities[4]);
		return u;
	}
	
	public static Movie lineToMovie(String line){
		String[] entities = line.split("\\|");
		String sub= entities[2];
		int year;
		if(!sub.isEmpty()){
			sub=entities[2].substring(7);
			year=Integer.parseInt(sub);
		}
		else{
			year=0;
		}
		ArrayList<String> genres=new ArrayList<String>();
		if(entities[5].equals("1"))
			genres.add("unknown");
		if(entities[6].equals("1"))
			genres.add("Action");
		if(entities[7].equals("1"))
			genres.add("Adventure");
		if(entities[8].equals("1"))
			genres.add("Animation");
		if(entities[9].equals("1"))
			genres.add("Children's");
		if(entities[10].equals("1"))
			genres.add("Comedy");
		if(entities[11].equals("1"))
			genres.add("Crime");
		if(entities[12].equals("1"))
			genres.add("Documentary");
		if(entities[13].equals("1"))
			genres.add("Drama");
		if(entities[14].equals("1"))
			genres.add("Fantasy");
		if(entities[15].equals("1"))
			genres.add("Film-Noir");
		if(entities[16].equals("1"))
			genres.add("Horror");
		if(entities[17].equals("1"))
			genres.add("Musical");
		if(entities[18].equals("1"))
			genres.add("Mystery");
		if(entities[19].equals("1"))
			genres.add("Romance");
		if(entities[20].equals("1"))
			genres.add("Sci-Fi");
		if(entities[21].equals("1"))
			genres.add("Thriller");
		if(entities[22].equals("1"))
			genres.add("War");
		if(entities[23].equals("1"))
			genres.add("Western");
		Movie m = new Movie(Long.parseLong(entities[0]), entities[1], year, genres);
		return m;
	}
	
	private static User getUserByID(long ID, ArrayList<User> users){
		for(User u: users){
			if(u.getID()==ID)
				return u;
		}
		return null;
	}
	private static Movie getMovieByID(long ID, ArrayList<Movie> movies){
		for(Movie m: movies){
			if(m.getID()==ID)
				return m;
		}
		return null;
	}
	
	public static Rating lineToRating(String line, ArrayList<User> users, ArrayList<Movie> movies){
		String[] entities = line.split("\\s");
		User u=MovieLens100kTranslator.getUserByID(Integer.parseInt(entities[0]), users);
		Movie m=MovieLens100kTranslator.getMovieByID(Integer.parseInt(entities[1]), movies);
		Rating r = new Rating(u, m, Double.parseDouble(entities[2]));
		return r; 
	}

	
	
	
	
	
	
}
