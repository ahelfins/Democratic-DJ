import java.util.ArrayList;
import java.util.Collections;


public class NetFlixPredictor {


	// Add fields to represent your database.
	private ArrayList<User> usersDatabase;
	private ArrayList<Movie> moviesDatabase;
	private ArrayList<Rating> ratingsDatabase;

	
	/**
	 * 
	 * Use the file names to read all data into some local structures. If any other database files are used,
	 * make sure they are stored in your Eclipse project and hardcode their location.
	 * 
	 * @param ratingsFilename The filename of the ratings database.
	 * @param usersFilename The filename of the users database.
	 * @param moviesFilename The filename of the movies database.
	 */
	public NetFlixPredictor(String ratingsFilename, String usersFilename, String moviesFilename) {
		FileIO reader = new FileIO();
		ArrayList<String> fileData1 = reader.readData(usersFilename);
		ArrayList<String> fileData2 = reader.readData(moviesFilename);
		ArrayList<String> fileData3 = reader.readData(ratingsFilename);
		usersDatabase = new ArrayList<User>();
		moviesDatabase = new ArrayList<Movie>();
		ratingsDatabase = new ArrayList<Rating>();
		 
		for (String s: fileData1){
			User newUser = MovieLens100kTranslator.lineToUser(s);
			usersDatabase.add(newUser);
		}
		for (String s: fileData2){
			Movie newMovie = MovieLens100kTranslator.lineToMovie(s);
			moviesDatabase.add(newMovie);
		}
		for (String s: fileData3){
			Rating newRating = MovieLens100kTranslator.lineToRating(s, usersDatabase, moviesDatabase);;
			ratingsDatabase.add(newRating);
		}
		
		Collections.sort(usersDatabase);
		Collections.sort(moviesDatabase);
	}
	

	/**
	 * Returns an array of objects representing movie data.
	 * 
	 * @return An array of objects representing individual movies.
	 */
	public Object[] getMovieData() {
		return moviesDatabase.toArray();
	}
	

	/**
	 * Returns an array of objects representing user data.
	 * 
	 * @return An array of objects representing individual users.
	 */
	public Object[] getUserData() {
		return usersDatabase.toArray();
	}

	
	/**
	 * If userNumber has rated movieNumber, return the rating. Otherwise, return -1.
	 * 
	 * @param userNumber The ID of the user.
	 * @param movieNumber The ID of the movie.
	 * @return The rating that userNumber gave movieNumber, or -1 if the user does not exist in the database, the movie does not exist, or the movie has not been rated by this user.
	 */
	public double getRating(long userID, long movieID) {
		for(Rating r: ratingsDatabase){
			if(r.getUser().getID()==userID){
				if(r.getMovie().getID()==movieID){
					return r.getStars();
				}
			}
		}
		return -1;
	}
	
	/**
	 * If userNumber has rated movieNumber, return the rating. Otherwise, use other available data to guess what this user would rate the movie.
	 * 
	 * @param userNumber The ID of the user.
	 * @param movieNumber The ID of the movie.
	 * @return The rating that userNumber gave movieNumber, or the best guess if the movie has not been rated by this user.
	 * @pre A user with id userID and a movie with id movieID exist in the database.
	 */
	public double guessRating(long userID, long movieID) {
		if(getRating(userID, movieID)!=-1)
			return getRating(userID, movieID);
		else{
			cacheAvgUserRatings();
			//User u = MovieLens100kTranslator.getUserByID(userID, usersDatabase);
			int userIndex=binarySearch(usersDatabase, userID);
			User u = usersDatabase.get(userIndex);
			Movie m = MovieLens100kTranslator.getMovieByID(movieID, moviesDatabase);
			double simAvgUser=0;
			double simAvgMovie=0;
			int countU=0;
			int countM=0;
			for(Rating r: ratingsDatabase){
				if(r.getUser().getID()==userID){
					if(m.areSimilar(r.getMovie())){
						simAvgMovie+=r.getStars();
						countM++;
					}
				}
				if(r.getMovie().getID()==movieID){
					if(areSimilar(u, r.getUser())){
						simAvgUser+=r.getStars();
						countU++;
					}
				}
			}
			double avg=(u.getAvgRat()+getAvgMovieRating(movieID))/2;
			if(countU>0){
				simAvgUser=simAvgUser/countU;
				avg=(avg*2+simAvgUser)/3;
			}
			if(countM>0&&countU>0){
				simAvgMovie=simAvgMovie/countM;
				avg=(avg*3+simAvgMovie)/4;
			}
			else if(countM>0){
				simAvgMovie=simAvgMovie/countM;
				avg=(avg*2+simAvgMovie)/3;
			}
			return avg;
		}
	}
	
	private void cacheAvgUserRatings(){
		for(Rating r: ratingsDatabase){
			r.getUser().addRat(r.getStars());
		}
	}
	private double getAvgMovieRating(long movieID){
		int movCount=0;
		double movAvg=0;
		for(Rating r: ratingsDatabase){
			if(r.getMovie().getID()==movieID){
				movAvg+=r.getStars();
				movCount++;
			}
		}
		if(movAvg==0){
			movAvg= 3;
			movCount=1;
		}
		movAvg=movAvg/movCount;
		return movAvg;
	}
	private boolean areSimilar(User u1, User u2){
		if(!(Math.abs(u1.getAge()-u2.getAge())<15&&u1.getGender()==u2.getGender())){
			return false;
		}	
		if(Math.abs(u1.getAvgRat()-u2.getAvgRat())<=2){
			return true;
		}
		return false;
	}
	
	public int binarySearch(ArrayList<User> database, long ID){
		return binarySearchRec(database, ID, 0, database.size()-1);
	}
	
	private int binarySearchRec(ArrayList<User> database, long ID, int start, int end){
	
		int index=(start+end)/2;
		User u=database.get(index);
		if(u.getID()==ID)
			return index;
		else if(u.getID()>ID)
			return binarySearchRec(database, ID, start, index-1);
		else
			return binarySearchRec(database, ID, index+1, end);
	}
	
}
