import java.util.ArrayList;
import java.util.Date;

public class Movie implements Comparable<Movie> {
	private ArrayList<String> genres;
	//private ArrayList<Rating> ratings;
	private long ID;
	private String title;
	private int releaseYear;
	
	public Movie(long ID, String title, int releaseYear, ArrayList<String> genres){
		this.ID=ID;
		this.title=title;
		this.releaseYear=releaseYear;
		this.genres = genres;
	}
	
	public long getID(){
		return ID;
	}
	public int getYear(){
		return releaseYear;
	}
	public ArrayList<String> getGenres(){
		return genres;
	}
	
	private int compareGenres(Movie m){
		int count=0;
		for(String s: genres){
			if(m.getGenres().indexOf(s)!=-1){
				count++;
			}
		}
		return count;
	}
	public boolean areSimilar(Movie m){
		if(!(Math.abs(releaseYear-m.getYear())<15&&compareGenres(m)>=2))
			return false;
		return true;
	}
	
	
	public String toString(){
		String ans="Movie ID: "+ID+", Title: "+title+", Year Released: "+releaseYear+", Genres: ";
		for(int i=0; i<genres.size(); i++)
			ans+=genres.get(i)+" ";
		return ans;
	}

	@Override
	public int compareTo(Movie o) {
		if(ID>o.getID())
			return 1;
		else if(ID<o.getID())
			return -1;
		else 
			return 0;
	}
	
	
}
