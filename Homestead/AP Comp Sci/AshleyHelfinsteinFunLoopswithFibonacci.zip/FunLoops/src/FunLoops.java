

/**
 * 
 * Number of Magic Squares (n): 1		2		3		4		5		6		7		8		9		10
 * Runtime (ns):				1866, 	1555, 	1555, 	3421, 	14306, 	78372, 	449707, 492003, 2937400,17504351 
 * 
 * @author AHelfinstein692
 *
 */
public class FunLoops {
	
	public static long factorial(long n){
		if(n==0){ //BASE CASE
			return 1;
		}
		else{ //RECURSIVE CASE
			long prevFact = factorial(n-1); 
			return n*prevFact;
		}
	}
	
	/**Returns the fibonacci number in a given position of the sequence
	 * @pre n>=0
	 * @param n the number of the position in the fibonacci sequence to be returned
	 * @return long the fibonacci number in the given position
	 */
	public static long fibonacci(long n){
		if(n==0||n==1){
			return n;
		}
		else{
			long prevN=fibonacci(n-1);
			long beforePrevN=fibonacci(n-2);
			return prevN+beforePrevN;
		}
		
	}
	
	
	
	public static int findLCM(int a, int b){
		if(a<b){
			int temp=a;
			a=b;
			b=temp;
		}
		int i=a;
		while(i%b!=0){
			i+=a;
		}
		return i;
		/*check which is bigger
		 * start the test value at the bigger one
		 * while the test value is not divisible by the smaller one
		 * 	increase the test value by the bigger one
		 * return the test value
		 * 
		 */
			
	}
	
	public static long[] findMagicSquares(int n){
		long[] answers = new long[n];
		long magicSquare=0;
		long num=1;
		long square=1;
		long sum=0;
		long x=0;
		for (int i=0; i<n; i++){
			while(magicSquare!=square){
				square=num*num;
				for(; sum<=square; sum+=x){
					if(sum==square){
						magicSquare=square;
						//System.out.println("Setting magic square");
					}
					x++;
				}
				num++;
			}
			answers[i]=magicSquare;
			//System.out.println("Found a magic square");
			magicSquare=0;
		}
		return answers;
	}
	
	public static void main(String args[]){
		
		System.out.println("Factorial: "+factorial(7));
		System.out.println("Fibonacci: " + fibonacci(6));
		
		/*System.out.println("LCM: "+ findLCM(15,18));
		System.out.println("LCM: "+ findLCM(40,12));
		System.out.println("LCM: "+ findLCM(2,7));
		System.out.println("LCM: "+ findLCM(100,5));
		int n=10;
		long[] x=new long[n];
		
		for(int b=1; b<=10; b++){
			long startTime = System.nanoTime();
			x=findMagicSquares(b);
			long endTime = System.nanoTime();
			System.out.print(endTime-startTime + ", ");
		}	
		System.out.println();
		for(int i=0; i<n; i++){
			System.out.println("Magic Square " + (i+1) + ": " + x[i]);
		}*/
			
	}

}
