import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * 
 * This class encrypts and decrypts text files using one of 3 algorithms:
 * 		Random monoalphabet, Vigenere, or Playfair
 * 
 * 
 * @author Ashley Helfinstein
 * @version 3/8/16
 * 
 */
public class Crypt {

	
	/**
	 * 
	 * An integer representing the algorithm chosen.
	 * Set to:
	 * 1 for random monoalphabet
	 * 2 for Vigenere
	 * 3 for Playfair
	 * 
	 */
	public static final int algorithm = 3;
	
	
	/**
	 * Reads from the file specified, and writes out an encrypted version of the file. If the output file already
	 * exists, overwrite it.
	 * 
	 * @param inputFilename The path of the file to be encrypted.
	 * @param outputFilename The path of the encrypted file to be saved.
	 * @param keyword The keyword to be used in the encryption algorithm.
	 * 
	 */
	public void encrypt(String inputFilename, String outputFilename, String keyword) 
	{
		String text = readData(inputFilename);
		String alpha="abcdefghiklmnopqrstuvwxyz";
		String encrypted="";
		char[][] playfair = new char[5][5];
		String key=keyword;
		for(int i=0; i<key.length(); i++){
			int ind=key.indexOf(key.charAt(i), i+1);
			if(ind!=-1){
				key=key.substring(0, ind)+key.substring(ind+1);
				i--;
			}
		}
		key=key.replace('j', 'i');
		key=key.replace('J', 'I');
		//System.out.println("Keyword: " + key);
		for(int i=key.length()-1; i>=0; i--){
			int ind=alpha.indexOf(key.charAt(i));
			alpha=key.charAt(i)+alpha.substring(0, ind)+alpha.substring(ind+1);		
		}
		//System.out.println("Alphabet: "+ alpha);
		text=text.replace('j', 'i');
		text=text.replace('J', 'I');
	
		//System.out.println(alpha+alpha.length());
		int count=0;
		for(int i=0; i<playfair.length; i++){
			for(int j=0; j<playfair[i].length; j++){
				playfair[i][j]=alpha.charAt(count);
				count++;
			}
		}
		
		//print line
		/*for(char[] c: playfair){
			for(char ch: c){
				System.out.print(ch+" ");
			}
			System.out.print('\n');
		}*/
		
		for(int i=0; i<text.length(); i+=2){
			char first=text.charAt(i);
			char second;
			boolean eof=false;
			String before="";
			String middle="";
			
			while(!Character.isLetter(first)){
				before+=first;
				i++;
				if(i>=text.length()){
					eof=true;
					break;
				}
				first=text.charAt(i);
			}
			if(eof){
				break;
			}
			if(i+1>=text.length()){
				second='i';
			}
			else{
				second=text.charAt(i+1);
				while(!Character.isLetter(second)){
					middle+=second;
					i++;
					if(i+1>=text.length()){
						second='i';
					}
					else{
						second=text.charAt(i+1);
					}	
				}
			}
			//System.out.println("First: "+first+" Second: "+second);
			int ind1=alpha.indexOf(Character.toLowerCase(first));
			int ind2=alpha.indexOf(Character.toLowerCase(second));
			//System.out.println("Ind1: "+ind1+" Ind2: "+ind2);
			int row1, col1, row2, col2;
			row1=ind1/5;
			col1=ind1%5;
			row2=ind2/5;
			col2=ind2%5;
			//System.out.println("Row1: "+row1+ " Row2: "+row2+" Col1: "+col1+" col2: "+col2);
			int numRows=Math.abs(row1-row2);
			int numCols=Math.abs(col1-col2);
			//System.out.println("NumRows: "+numRows+ " NumCols: "+numCols);
			char enc1, enc2;
			if(col1>col2){
				enc1=playfair[row1][col1-numCols];
				enc2=playfair[row2][col2+numCols];
			}
			else if(col1==col2){
				enc1=playfair[row2][col1];
				enc2=playfair[row1][col2];
			}	
			else{
				enc1=playfair[row1][col1+numCols];
				enc2=playfair[row2][col2-numCols];
			}
			encrypted+=before+enc1+middle+enc2;
		}
		
		writeData(encrypted, outputFilename);
	}
	
	private String readData(String fileName) {
		File readFile = new File(fileName);
		if(!readFile.exists()){
			System.err.println("File "+fileName+" does not exist.");
			return null;
		}
		
		BufferedReader in = null;
		
		try{
			in = new BufferedReader(new FileReader(fileName)); 
			
			String fileData="";
			
			while(in.ready()){
				String input=in.readLine();
				fileData=fileData.concat(input)+"\n";
			}
			
			return fileData;
		}
		catch(IOException ex){
			ex.printStackTrace();
			return null;
		}
		finally{
				try {
					if(in != null)
						in.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	
	}
	
	private void writeData(String encrypted, String outputFilename){
		BufferedWriter out = null;
		
		try {
			out = new BufferedWriter(new FileWriter(outputFilename));
			out.write(encrypted);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
				try {
					if(out != null)
						out.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	/**
	 * Reads from the (previously encrypted) file specified, and writes out a decrypted version of the file. 
	 * If the output file already exists, overwrite it.
	 * 
	 * @param inputFilename The path of the encrypted file.
	 * @param outputFilename The path of the decrypted file to be saved.
	 * @param keyword The keyword to be used in the decryption algorithm.
	 * 
	 */
	public void decrypt(String inputFilename, String outputFilename, String keyword) 
	{
		
	}

	
	
}
