
public class OldMacDonald {
  public static void main(String[] args){
	    Cow c = new Cow();
	    Pig p = new Pig();
	    Chick ch = new Chick(true);
	    NamedCow co = new NamedCow("Elsie");
	    //System.out.println( c );
	    //System.out.println( p );
	    //System.out.println( ch );
	    //System.out.println(co);
	    
	    Farm f = new Farm();
	    //f.printAnimalSounds();
	    f.printOldMacDonaldSong();
	    
	  }

}
