
public class Chick implements Animal {
	private String myType;
	  private String mySound;
	  private String mySound2;
	  private boolean twoSounds;

	  Chick(){
	    myType = "chick";
	    mySound = "cheep";
	    twoSounds=false;
	  }
	  public Chick(boolean twoSounds){
		  this.twoSounds=twoSounds;
		  myType = "chick";
		  mySound = "cheep";
		  mySound2 = "cluck";
	  }

	  public String getSound() {
	  	if(twoSounds){
	  		double ran = Math.random();
	  		if(ran<0.5)
	  			return mySound;
	  		else
	  			return mySound2;	
	  	}
	  	else
		  return mySound;
	  }

	  public String getType() {
	 	return myType;
	  }

	  public String toString() {
		return "The " + getType() + " goes " + getSound();
	  }
}
