import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Squeeze {
	
	private String text;
	
	public Squeeze(String filename){
		text=readData(filename);
	}
	
	public String readData(String fileName){
		String ans = "";
		try{
			FileReader reader = new FileReader(fileName); 
			Scanner in = new Scanner(reader); 
			while(in.hasNext()){
				ans+=in.nextLine();
				ans+="\n";
			}
		}
		catch(IOException ex){
			System.out.println("Problem reading file");
		}
		return ans;
	}
	
	public void addCounts(){
		int count=0;
		int i=0;
		while(i<text.length()&&i!=-1){
			while(text.charAt(i)==' '){
				count++;
				text=text.substring(0,i)+text.substring(i+1);
			}
			text=text.substring(0, i)+count+" "+text.substring(i);
			count=0;
			i=text.indexOf('\n',i)+1;
		}
		
			
	}
	
	public String toString(){
		return text;
	}

	
	public static void main(String[]args) throws IOException{
		Squeeze s = new Squeeze("squeeze.txt");
		FileWriter writer = new FileWriter("newSqueeze.txt");
		s.addCounts();
		writer.write(s.toString());
		writer.close();
	}
	
} 
