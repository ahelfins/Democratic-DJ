import processing.core.PApplet;
import shapes.*;
	
public class Sierpinski {

	private int level; 
	private double sideLength; 
	
	public Sierpinski(int level, int length) {
		this.level=level;
		sideLength=length;
	}
	
	public void draw(PApplet marker) {
		drawSierpinski(marker, level, 300, 50, sideLength);
	}
	
	//x and y are the top point of the triangle
	private void drawSierpinski(PApplet drawer, int level, double x, double y, double sideLength) {
		drawer.fill(0);
		if(level<1){
			double y2=y+Math.sqrt(Math.pow(sideLength, 2)-Math.pow(sideLength/2, 2));
			drawer.triangle((float)x, (float)y, (float)(x+sideLength/2), (float)y2, (float)(x-sideLength/2), (float)y2);
		}
		else{
			drawSierpinski(drawer, level-1, x, y, sideLength/2);
			x-=sideLength/4;
			y+=(Math.sqrt(Math.pow(sideLength, 2)-Math.pow(sideLength/2, 2)))/2;
			drawSierpinski(drawer, level-1, x, y, sideLength/2);
			x+=sideLength/2;
			drawSierpinski(drawer, level-1, x, y, sideLength/2);
		}
	}


}
