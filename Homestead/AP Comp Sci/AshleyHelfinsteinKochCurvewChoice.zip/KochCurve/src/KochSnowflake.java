import processing.core.PApplet;
import shapes.Line;

public class KochSnowflake {
	private int level; 
	private double length; 

    public KochSnowflake(int level, int length) {
    	this.level=level;
    	this.length=length;
    }
    
    public void draw(PApplet marker) {
    	drawKochCurve(marker, level, 100, 200, 0.0, length);
    	drawKochCurve(marker, level, 100+length, 200, 4*Math.PI/3, length);
    	drawKochCurve(marker, level, 100+length/2, 200+(Math.sqrt(Math.pow(length, 2)-Math.pow(length/2, 2))), 2*Math.PI/3, length);
    }

    private void drawKochCurve(PApplet drawer, int level, double x, double y, double angle, double length) {
    	if (level < 1){
    		Line l = new Line((int)x, (int)y, angle, length);
    		l.draw(drawer);    		
    	}
    	else{
    		drawKochCurve(drawer, level-1, x, y, angle, length/3);
    		Line l= new Line((int)x, (int)y, angle, length/3);
    		x=l.getPoint2X();
    		y=l.getPoint2Y();
    		angle+=Math.PI/3;
    		drawKochCurve(drawer, level-1, x, y, angle, length/3);
    		l=new Line((int)x, (int)y, angle, length/3);
    		x=l.getPoint2X();
    		y=l.getPoint2Y();
    		angle-=2*Math.PI/3;
    		drawKochCurve(drawer, level-1, x, y, angle, length/3);
    		l=new Line((int)x, (int)y, angle, length/3);
    		x=l.getPoint2X();
    		y=l.getPoint2Y();
    		angle+=Math.PI/3;
    		drawKochCurve(drawer, level-1, x, y, angle, length/3);
    	}
    }
    
		   
}
