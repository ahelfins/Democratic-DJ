import processing.core.PApplet;
import shapes.*;

/**
  @(#)KochCurve.java


  @author
  @version
*/
public class KochCurve {

	private int level; 
	private double length; 

    public KochCurve(int level, int length) {
    	this.level=level;
    	this.length=length;
    }
    
    public void draw(PApplet marker) {
    	drawKochCurve(marker, level, 100, 200, 0.0, length);
    }

    private void drawKochCurve(PApplet drawer, int level, double x, double y, double angle, double length) {
    	if (level < 1){
    		Line l = new Line((int)x, (int)y, angle, length);
    		l.draw(drawer);
    		
    		
    	}
    	else{
		  //Draw a k-1 level Koch curve with segments 1/3 the current length
    		drawKochCurve(drawer, level-1, x, y, angle, length/3);
    		Line l= new Line((int)x, (int)y, angle, length/3);
    		x=l.getPoint2X();
    		y=l.getPoint2Y();
		 // Turn left 60 degrees
    		angle+=Math.PI/3;
		  //Draw a k-1 level Koch curve with segments 1/3 the current length
    		drawKochCurve(drawer, level-1, x, y, angle, length/3);
    		l=new Line((int)x, (int)y, angle, length/3);
    		x=l.getPoint2X();
    		y=l.getPoint2Y();
		  //Turn right 120 degrees
    		angle-=2*Math.PI/3;
		  //Draw a k-1 level Koch curve with segments 1/3 the current length
    		drawKochCurve(drawer, level-1, x, y, angle, length/3);
    		l=new Line((int)x, (int)y, angle, length/3);
    		x=l.getPoint2X();
    		y=l.getPoint2Y();
		  //Turn left 60 degrees
    		angle+=Math.PI/3;
		  //Draw a k-1 level Koch curve with segments 1/3 the current length
    		drawKochCurve(drawer, level-1, x, y, angle, length/3);
		   
    	}
    }

}
