
public class StatisticsCalculator {
	
	public StatisticsCalculator(){
		
	}
	//1) Read from the file
	public int[] readData(String filename){
		ArrayReader reader = new ArrayReader(filename);
		int[] data = new int[1000];
		reader.fillArray(data);
		return data;
	}
	//2) Calculate average of an array
	public double calcAverage(int[] data){
		long sum=0;
		for(int x: data){
			sum+=x;
		}
		return sum/(double)(data.length);
	}
	
	//3) Calculate mode of an array
	//using foreach
	public int[] findMode(int[] data, int max){
		int[] modes=new int[data.length];
		int[] repetitions=new int[max+1]; 
		int maxRep=0;
		for(int x: data){
			repetitions[x]=repetitions[x]+1; 
			if(repetitions[x]>maxRep)
				maxRep=repetitions[x];
		}
		int m=0;
		for(int i=0; i<=max; i++){
			if(repetitions[i]==maxRep){
				modes[m]=i; 
				m++;
			}
		}
		int[] finModes = new int[m];
		for(int y=0; y<m; y++)
			finModes[y]=modes[y];
		return finModes;
	}
	//4) Calculate standard deviation of an array
	public double calcStdDeviation(int[]data){
		double average=calcAverage(data);
		long preVar=0;
		for(int x: data){
			preVar+=(Math.pow((x-average), 2));
		}
		double variance=preVar/(double)(data.length-1);
		return Math.sqrt(variance);
	}

	
	public static void main(String[] args){
		StatisticsCalculator calc = new StatisticsCalculator();
		int[] data = calc.readData("numbers.txt");
		int[] practice = {7, 4, 8, 6, 7, 6, 4, 5, 7, 6};
		int[] modes = calc.findMode(data, 100);
		/*for(int x: data)
		{
			System.out.println(x);
		}*/
		System.out.println(calc.calcAverage(data));
		System.out.println(calc.calcStdDeviation(data));
		for(int x: modes)
			System.out.println(x);
	}
}
